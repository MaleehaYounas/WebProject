const { Login, getAllRecipients, getRecipientById, createRecipient, updateRecipientById, deleteRecipientById, giveFeedbackToDonor, seeFeedback, seeAllFeedback, giveAppFeedback, getAllFeedback } = require("../Controller/RecipientController")

const express = require("express");
const { AuthenticateUser } = require("../utils");
const router2 = express.Router();

router2.post("/create" , createRecipient)
router2.post ("/login", Login )
router2.get("/" , AuthenticateUser, getAllRecipients)
router2.get('/seeYourFeedback' , AuthenticateUser, seeFeedback), // see donor given feedbak
router2.get('/seeAllFeedback', seeAllFeedback), // 
router2.post('/feedback', AuthenticateUser, giveAppFeedback); // give spp feedback
router2.get('/feedback', getAllFeedback); // see the recipeint feedback about yoour app
router2.get("/:id" ,AuthenticateUser, getRecipientById)
router2.patch("/:id" ,AuthenticateUser, updateRecipientById)
router2.delete("/:id" ,AuthenticateUser,  deleteRecipientById)
router2.post('/giveFeedbackToDonor/:id', AuthenticateUser, giveFeedbackToDonor )

module.exports = router2;


