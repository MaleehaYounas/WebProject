import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './Components/Home';
import NavBar from './Components/NavBar';
import Footer from './Components/Footer';
import Login from "./Components/Login";
import RegisterRecipient from "./Components/RegisterRecipient";
import Register from "./Components/Register";
import RecipientPortal from "./Components/RecipientPortal";

// import DonorList from "./Components/DonorList";
// import AdminPortal from './Components/AdminPortal';
// import DonorDetails from './Components/DonorDetails'; 
// import RecipientDetails from './Components/RecipientDetails'; 
const isLogin= true;
function App() {
  return (
    <Router>
      <div>
        <NavBar  isLogin={isLogin}/>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/login" element={<Login />} />
          {/* <Route path="/adminPortal" element={<AdminPortal />} />
          <Route path="/donorList" element={<DonorList />} />
          <Route path="/donor-details/:donorId" element={<DonorDetails />} /> 
          <Route path="/recipient-details/:recipientId" element={<RecipientDetails />} />  */}
          <Route path="/recipientPortal" element={<RecipientPortal/>} />
          <Route path="/register" element={<Register/>} />
          <Route path="/registerAsRecipient" element={<RegisterRecipient/>}/>
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
