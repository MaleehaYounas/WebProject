import React, { useState, useEffect } from 'react';
import { jwtDecode } from 'jwt-decode';
import '../App.css';

const RecipientDetails = ({ match }) => {
  const token = localStorage.getItem('token');
  const decodedToken = jwtDecode(token);
  const recipientId = decodedToken.id;

  const [recipient, setRecipient] = useState(null);
  const [editableRecipient, setEditableRecipient] = useState(null);
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    const fetchRecipientById = async () => {
      try {
        const response = await fetch(`http://localhost:3003/recipient/${recipientId}`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            token: token,
          },
        });
        if (response.ok) {
          const recipientData = await response.json();
          setRecipient(recipientData);
          setEditableRecipient(recipientData); // Initialize editable fields with the fetched data
        } else {
          console.error('Error fetching recipient:', response.status);
        }
      } catch (error) {
        console.error('Error:', error);
      }
    };

    fetchRecipientById();
  }, [recipientId, token]);

  const handleEditClick = () => {
    setIsEditing(true);
  };

  const handleSaveClick = async () => {
    try {
      const response = await fetch(`http://localhost:3003/recipient/${recipientId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          token: token,
        },
        body: JSON.stringify(editableRecipient),
      });
  
      if (response.ok) {
        const updatedRecipient = await response.json();
        
        // Update editableRecipient state with the new values
        setEditableRecipient(updatedRecipient);
        // Update recipient state (if needed)
        setRecipient(updatedRecipient);
  
        // Disable editing mode
        setIsEditing(false);
      } else {
        console.error('Error updating recipient:', response.status);
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };
  

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditableRecipient((prevEditableRecipient) => ({
      ...prevEditableRecipient,
      [name]: value,
    }));
  };

  return (
    <div className="container mt-5">
      {recipient ? (
        <div>

          <h2>{recipient.name}</h2>
          <p>Email: {recipient.email}</p>

          {isEditing ? (
            <>
              <label>Occupation:</label>
              <input
                type="text"
                name="occupation"
                value={editableRecipient.occupation}
                onChange={handleInputChange}
              />
              <br />

              <label>Income:</label>
              <input
                type="text"
                name="income"
                value={editableRecipient.income}
                onChange={handleInputChange}
              />
              <br />

              <label>Needs:</label>
              <input
                type="text"
                name="needs"
                value={editableRecipient.needs}
                onChange={handleInputChange}
              />
              <br />

              <label>Phone:</label>
              <input
                type="tel"
                name="phone"
                value={editableRecipient.phone}
                onChange={handleInputChange}
              />
              <br />

              <label>Address:</label>
              <textarea
                name="address"
                value={editableRecipient.address}
                onChange={handleInputChange}
              ></textarea>
              <br />

              <label>Religion:</label>
              <input
                type="text"
                name="religion"
                value={editableRecipient.religion}
                onChange={handleInputChange}
              />
              <br />

              {/* Add more editable fields as needed */}
              <button onClick={handleSaveClick}>Save</button>
            </>
          ) : (
            <>
              <p>Occupation: {recipient.occupation}</p>
              <p>Income: {recipient.income}</p>
              <p>Needs: {recipient.needs}</p>
              <p>Phone: {recipient.phone}</p>
              <p>Address: {recipient.address}</p>
              <p>Religion: {recipient.religion}</p>

              {/* Add more details as needed */}
              <button onClick={handleEditClick}>Edit</button>
            </>
          )}
        </div>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
};

export default RecipientDetails;
