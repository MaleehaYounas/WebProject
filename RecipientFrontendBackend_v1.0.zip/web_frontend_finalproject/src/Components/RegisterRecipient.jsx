import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const CreateRecipientForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    role: 'recipient',
    email: '',
    password: '',
    cnic: '',
    occupation: '',
    income: '',
    needs: '',
    phone: '',
    address: '',
    religion: '',
    // profilePicture: null,
    // documents: null,
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };
  const navigate = useNavigate();
//   const handleFileChange = (e) => {
//     const { name, files } = e.target;
//     setFormData({ ...formData, [name]: files[0] });
//   };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const form = new FormData();
    Object.entries(formData).forEach(([key, value]) => {
      form.append(key, value);
    });
    
    console.log("Form Data:", form);
    try {
      const response = await fetch('http://localhost:3003/recipient/create', {
        method: 'POST',
        body:  new FormData(e.target),
        // headers: {
        //     'Content-Type': `multipart/form-data; boundary=${form._boundary}`,
        // },
      });

      if (response.ok) {
        const result = await response.json();
        console.log('Recipient created:', result);

        // Redirect to login page after a successful response
        setTimeout(() => {
          navigate('/login');
        }, 2000); // Adjust the delay as needed
      }
      
      else {
        const error = await response.json();
        console.error('Error creating recipient:', error);
        // Handle error, e.g., show an error message to the user
      }
    } catch (error) {
      console.error('Error:', error);
      // Handle network error or other issues
    }
  };

  return (
    <section className="background3">
      <div className="container mt-5">
        <div className="row justify-content-center">
          <div className="col-md-6">
            <form onSubmit={handleSubmit} className="rounded p-4 shadow-lg bg-light">
              <h2 className="text-center mb-4 text-primary">Create Recipient</h2>

         <div className="mb-3">
        <label className="form-label">Name:</label>
        <input type="name" name="name" className="form-control" onChange={handleInputChange} />
      </div>

      <div className="mb-3">
        <label className="form-label">Email:</label>
        <input type="email" name="email" className="form-control" onChange={handleInputChange} />
      </div>

      <div className="mb-3">
        <label className="form-label">Password:</label>
        <input type="password" name="password" className="form-control" onChange={handleInputChange} />
      </div>

      <div className="mb-3">
        <label className="form-label">CNIC:</label>
        <input type="text" name="cnic" className="form-control" onChange={handleInputChange} />
      </div>

      <div className="mb-3">
        <label className="form-label">Occupation:</label>
        <input type="text" name="occupation" className="form-control" onChange={handleInputChange} />
      </div>

      <div className="mb-3">
        <label className="form-label">Income:</label>
        <input type="text" name="income" className="form-control" onChange={handleInputChange} />
      </div>

      <div className="mb-3">
        <label className="form-label">Needs:</label>
        <input type="text" name="needs" className="form-control" onChange={handleInputChange} />
      </div>

      <div className="mb-3">
        <label className="form-label">Phone:</label>
        <input type="tel" name="phone" className="form-control" onChange={handleInputChange} />
      </div>

      <div className="mb-3">
        <label className="form-label">Address:</label>
        <textarea name="address" className="form-control" onChange={handleInputChange}></textarea>
      </div>

      <div className="mb-3">
        <label className="form-label">Religion:</label>
        <input type="text" name="religion" className="form-control" onChange={handleInputChange} />
      </div>

      {/* <div className="mb-3">
        <label className="form-label">Profile Picture:</label>
        <input type="file" name="profilePicture" className="form-control" onChange={handleFileChange} />
      </div>

      <div className="mb-3">
        <label className="form-label">Document: </label>
        <input type="file" name="documents" className="form-control"  onChange={handleFileChange} />
      </div> */}

      <button type="submit" className="btn btn-primary">Create Recipient</button>
      </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CreateRecipientForm;
