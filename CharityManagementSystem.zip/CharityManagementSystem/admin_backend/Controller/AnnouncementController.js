const Announcement = require('../models/Announcement.schema');


//Get all announcements
const getAllAnnouncements = async (req, res) => {
    try {
      const announcements = await Announcement.find().sort({ createdAt: -1 });
      res.json(announcements);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Server error' });
    }
  };
  
  //Add new announcement
const addAnnouncement = async (req, res) => {
    try {
      // Check if the user is 'admin'
      if (req.role !== 'admin') {
        return res.status(403).json({ message: 'You are not authorized for this action' });
      }
  
      const { title, content } = req.body;
      const newAnnouncement = new Announcement({
        title,
        content,
      });
      const savedAnnouncement = await newAnnouncement.save();
      res.json(savedAnnouncement);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Server error' });
    }
  };
  
  //Delete announcement
const deleteAnnouncement = async (req, res) => {
    try {
      // Check if the user is 'admin'
      if (req.role !== 'admin') {
        return res.status(403).json({ message: 'You are not authorized for this action' });
      }
  
      const { id } = req.params;
      const deletedAnnouncement = await Announcement.findByIdAndDelete(id);
      if (deletedAnnouncement) {
        res.json({ message: 'Announcement deleted' });
      } else {
        res.status(404).json({ message: 'Announcement not found' });
      }
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Server error' });
    }
  };

module.exports= {
    getAllAnnouncements,
    addAnnouncement,
    deleteAnnouncement

};


