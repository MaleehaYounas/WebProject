// const blog = require("../models/Blog.schema") 

// // Route to search for a word 
// const searchByWord = async (req, res) => {
//     try {
//         const word = req.params.word;
        
//         // Writing query to search for the word in title of blog
//         const query = { description: { $regex: word, $options: 'i' } };

//         // Execute the query and sorting
//         const searchResults = await blog.find(query).sort({ createdAt: -1 });

            
//         // Respond with the search results
//         res.status(200).json(searchResults);
//     } catch (err) {
//         console.error(err);
//         res.status(500).json({ "Message": "Server error" });
//     }
// };

const data = [
    { id: 1, title: 'Donor Management', content: 'Manage information about donors.' },
    { id: 2, title: 'Recipient Management', content: 'Manage information about recipients.' },
    // Add more data as needed
  ];
  
  const searchByWord = async (req, res) => {
    const searchTerm = req.query.q.toLowerCase();
  
    const results = data.filter(item => {
      return item.title.toLowerCase().includes(searchTerm) || item.content.toLowerCase().includes(searchTerm);
    });
  
    res.json(results);
  };

module.exports = {searchByWord};