
const Donor = require("../models/Donor.schema");

const Recipient = require("../models/Recipient.schema");
const searchDonorsByWord = async (req, res) => {
    try {
        const word = req.params.word;

        // Search in Donor data
        const donorQuery = {
            $or: [
                { name: { $regex: word, $options: 'i' } },
                { email: { $regex: word, $options: 'i' } },
                { phone: { $regex: word, $options: 'i' } },
                { address: { $regex: word, $options: 'i' } },
                { occupation: { $regex: word, $options: 'i' } },
                { religion: { $regex: word, $options: 'i' } },
             
            ],
        };
        const donorResults = await Donor.find(donorQuery);

        res.status(200).json(donorResults);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
};



const searchRecipientsByWord = async (req, res) => {
    try {
        const word = req.params.word;
        console.log('Searched Term:', word);
       
        // Search in Recipient data
        const recipientQuery = {
            $or: [
                { name: { $regex: word, $options: 'i' } },
                { email: { $regex: word, $options: 'i' } },
                { phone: { $regex: word, $options: 'i' } },
                { address: { $regex: word, $options: 'i' } },
                { occupation: { $regex: word, $options: 'i' } },
                { religion: { $regex: word, $options: 'i' } },
                { need: { $regex: word, $options: 'i' } },
                { cnic: { $regex: word, $options: 'i' } },
            ],
        };
        const recipientResults = await Recipient.find(recipientQuery);
        console.log('Query:', recipientQuery);
        
        res.status(200).json(recipientResults);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
};


module.exports = {searchDonorsByWord,searchRecipientsByWord };
