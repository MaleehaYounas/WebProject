const {searchByWord} = require("../Controller/SearchController")

const express = require("express");

const router3 = express.Router();


router3.get("/:word" ,searchByWord);

module.exports = router3;