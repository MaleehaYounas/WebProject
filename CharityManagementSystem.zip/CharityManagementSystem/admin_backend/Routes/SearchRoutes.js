const {searchDonorsByWord, searchRecipientsByWord} = require("../Controller/SearchController")

const express = require("express");
const { AuthenticateUser } = require("../utils");
const router3 = express.Router();

router3.get("/donor/:word" ,AuthenticateUser, searchDonorsByWord);
router3.get("/recipient/:word" ,AuthenticateUser, searchRecipientsByWord);
module.exports = router3;