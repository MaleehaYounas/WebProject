const {getDonorFeedback, getRecipientFeedback, replyToFeedback, deleteFeedback} = require("../Controller/FeedbackController")

const express = require("express");
const { AuthenticateUser } = require("../utils");
const router4 = express.Router();

router4.put('/:id/reply',AuthenticateUser, replyToFeedback);
router4.delete('/:id',AuthenticateUser, deleteFeedback);
router4.get('/donor', getDonorFeedback);
router4.get('/recipient', getRecipientFeedback);

module.exports = router4;