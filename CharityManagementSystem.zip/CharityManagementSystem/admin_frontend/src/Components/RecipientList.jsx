// RecipientList.jsx
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import "../App.css";

const RecipientList = () => {
  const [recipients, setRecipients] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchRecipients = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await fetch('http://localhost:3001/admin/get-all-recipients', {
          headers: {
            token: token,
          },
        });

        if (!response.ok) {
          throw new Error(`Failed to fetch recipients. Status: ${response.status}`);
        }

        const data = await response.json();
        setRecipients(data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching recipients:', error.message);
        setLoading(false);
      }
    };

    fetchRecipients();
  }, []);

  const handleRecipientClick = (recipientId) => {
    navigate(`/recipient-details/${recipientId}`);
  };

  return (
    <div style={{ margin: 0 }}>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {recipients.map((recipient, index) => (
            <React.Fragment key={recipient.id}>
              <li
                onClick={() => handleRecipientClick(recipient._id)}
                className="donor-recipient-list-text"
              >
                <strong>{recipient.name}</strong> - {recipient.needs}
              </li>
            </React.Fragment>
          ))}
        </ul>
      )}
    </div>
  );
};

export default RecipientList;
