import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import "../App.css";
import SearchBar from './SearchBar';

const RecipientList = () => {
  const [recipients, setRecipients] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const token = localStorage.getItem('token');
  useEffect(() => {
    const fetchRecipients = async () => {
      try {
        
        const response = await fetch('http://localhost:3001/admin/get-all-recipients', {
          headers: {
            token: token,
          },
        });

        if (!response.ok) {
          throw new Error(`Failed to fetch recipients. Status: ${response.status}`);
        }

        const data = await response.json();
        setRecipients(data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching recipients:', error.message);
        setLoading(false);
      }
    };

    fetchRecipients();
  }, []);





  const handleSearch = async (searchTerm) => {
    try {
      setLoading(true);
    
      const response = await fetch(`http://localhost:3001/search/recipient/${searchTerm}`, {
        headers: {
          token: token,
        },
      });
      if (!response.ok) {
        throw new Error(`Failed to fetch search results. Status: ${response.status}`);
      }
  
      const data = await response.json();
      console.log('Search results:', data);
  
      if (data.length === 1) {
        const recipientId = data[0]._id;
        console.log('Navigating to recipient details:', recipientId);
        navigate(`/recipient-details/${recipientId}`);
      } else if (data.length > 1) {
        // Handle the case when there are multiple results
        console.log('Multiple matching recipients found. Display a list or choose the first one.');
      } else {
        console.log('No matching recipients found');
      }
  
      setLoading(false);
    } catch (error) {
      console.error('Error searching recipients:', error.message);
      setLoading(false);
    }
  };
  
  









  const handleRecipientClick = (recipientId) => {
    navigate(`/recipient-details/${recipientId}`);
  };

  return (
    <div style={{ margin: 0 }}>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <div>
        <h2 className='text-center p-1 heading-container'>Recipients</h2>
        <SearchBar
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        handleSearch={handleSearch}
      />
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {recipients.map((recipient, index) => (
            <React.Fragment key={recipient.id}>
              <li
                onClick={() => handleRecipientClick(recipient._id)}
                className="donor-recipient-list-text"
              >
                <strong>{recipient.name}</strong> - {recipient.needs}
              </li>
            </React.Fragment>
          ))}
        </ul>
        </div>
      )}
    </div>
    
  );
};

export default RecipientList;
