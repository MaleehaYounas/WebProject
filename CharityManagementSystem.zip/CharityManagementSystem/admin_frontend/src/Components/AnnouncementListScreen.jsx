import React from 'react';
import AnnouncementList from './AnnouncementList';

const AnnouncementListScreen = () => {
  return (
    <div className="all-screens-bg all_screen_padding ">
      <AnnouncementList />
    </div>
  );
};

export default AnnouncementListScreen;
