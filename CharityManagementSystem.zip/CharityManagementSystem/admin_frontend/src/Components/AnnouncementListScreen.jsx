import React from 'react';
import AnnouncementList from './AnnouncementList';

const AnnouncementListScreen = () => {
  return (
    <div className="all-screens-bg">
      <h2>Announcement List</h2>
      <AnnouncementList />
    </div>
  );
};

export default AnnouncementListScreen;
