// DonorDetails.jsx
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';

const DonorDetails = () => {
  const { donorId } = useParams();
  const [donor, setDonor] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isBlocked, setIsBlocked] = useState(false);

  useEffect(() => {
    const fetchDonorDetails = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await fetch(`http://localhost:3001/admin/get-donor-by-id/${donorId}`, {
          headers: {
            token: token,
          },
        });

        if (!response.ok) {
          throw new Error(`Failed to fetch donor details. Status: ${response.status}`);
        }

        const data = await response.json();
        setDonor(data);
        setIsBlocked(data.isBlocked);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching donor details:', error.message);
        setLoading(false);
      }
    };

    fetchDonorDetails();
  }, [donorId]);

  const handleBlockToggle = async () => {
    try {
      const token = localStorage.getItem('token');
      const action = isBlocked ? 'unblock' : 'block';

      const response = await fetch(`http://localhost:3001/admin/${action}-user/${donorId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          token: token,
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to ${action} donor. Status: ${response.status}`);
      }

      setIsBlocked(!isBlocked);
    } catch (error) {
      console.error(`Error ${isBlocked ? 'unblocking' : 'blocking'} donor:`, error.message);
    }
  };

  return (
    <div className='all-screens-bg'>
      <h2>Donor Details</h2>
      {loading ? (
        <p>Loading...</p>
      ) : donor ? (
        <div>
          <p>Name: {donor.name}</p>
          <p>Email: {donor.email}</p>
          {/* Add other donor details here */}
          <p>Status: {isBlocked ? 'Blocked' : 'Active'}</p>
          <button onClick={handleBlockToggle}>
            {isBlocked ? 'Unblock Donor' : 'Block Donor'}
          </button>
        </div>
      ) : (
        <p>Donor not found</p>
      )}
    </div>
  );
};

export default DonorDetails;
