import React from 'react';
import AddAnnouncement from './AddAnnouncement';
import { jwtDecode } from 'jwt-decode';
import '../App.css';

const AddAnnouncementScreen = () => {
  const token = localStorage.getItem('token');
  const decodedToken = jwtDecode(token);
  const name = decodedToken.name;
  const pic = decodedToken.profilePicture;
  return (

    <div className='all-screens-bg all_screen_padding'>
      <div className="profile-container ">
        <div className="profile-info">
          <img src={`http://localhost:3001/uploads/${pic}`} className="img-dim round-image" alt={pic} />
          <h4>{name}</h4>
        </div>
      </div>
      <div>
        <AddAnnouncement />
      </div>
    </div>
  );
};

export default AddAnnouncementScreen;
