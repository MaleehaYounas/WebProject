import React from 'react';
import AddAnnouncement from './AddAnnouncement';

const AddAnnouncementScreen = () => {
  return (
    <div className="all-screens-bg">
      <h2>Add Announcement</h2>
      <AddAnnouncement />
    </div>
  );
};

export default AddAnnouncementScreen;
