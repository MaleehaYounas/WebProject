import React, { useState } from 'react';
import searchIcon from '../Images/search_icon.png'; 

const SearchBar = ({ handleSearch }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault(); 
    handleSearch(searchTerm);
  };

  return (
    <form onSubmit={handleSubmit} style={{ display: 'flex', alignItems: 'center' }}>
      <input
        type="text"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        placeholder="Search"
        style={{ marginLeft: '4px', padding: '3px', border: 'none', width: '100%' }}
      />
      <button
        type="submit"
        style={{
          border: 'none',
          background: 'transparent',
          cursor: 'pointer',
          backgroundColor: 'white',
          marginRight: '10px',
        }}
      >
        <img src={searchIcon} alt="Search Icon" width="24" height="28" />
      </button>
    </form>
  );
};

export default SearchBar;
