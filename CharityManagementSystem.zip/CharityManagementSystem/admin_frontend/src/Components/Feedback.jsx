import React from 'react';
import { useNavigate } from 'react-router-dom';
import DonorFeedback from './DonorFeedbackList';
import RecipientFeedback from './RecipientFeedbackList';
import '../App.css';
import { jwtDecode } from 'jwt-decode';

const Feedback = () => {
  const token = localStorage.getItem('token');
  const decodedToken = jwtDecode(token);
  const name = decodedToken.name;
  const pic = decodedToken.profilePicture;

  return (
    <div className="all_screen_padding all-screens-bg">
      <div className="profile-container">
        <div className="profile-info">
          <img src={`http://localhost:3001/uploads/${pic}`} className="img-dim round-image" alt={pic} />
          <h4 style={{ marginLeft: '20px' }}>{name}</h4>
        </div>
      </div>
      
      <div className="lists-container mt-5">
        <div className="list lists-containers">
          <DonorFeedback />
        </div>
        <div className="list lists-containers">
        
          <RecipientFeedback />
        </div>
      
      
      </div>
    </div>
  );
};

export default Feedback;
