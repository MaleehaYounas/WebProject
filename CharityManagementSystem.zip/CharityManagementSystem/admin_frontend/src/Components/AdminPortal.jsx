import React from 'react';
import { useNavigate } from 'react-router-dom';
import DonorList from './DonorList';
import RecipientList from './RecipientList';
import '../App.css';
import { jwtDecode } from 'jwt-decode';

const AdminPortal = () => {
  const token = localStorage.getItem('token');
  const decodedToken = jwtDecode(token);
  const name = decodedToken.name;
  const pic = decodedToken.profilePicture;
  const navigate = useNavigate();

  const handleAddAnnouncementClick = () => {
    navigate('/add-announcement');
  };

  const handleViewAnnouncementsClick = () => {
    navigate('/announcement-list');
  };

  const handleFeedbacksClick = () => {
    navigate('/feedback');
  };

  return (
    <div className="all_screen_padding all-screens-bg">
      <div className="profile-container">
        <div className="profile-info">
          <img src={`http://localhost:3001/uploads/${pic}`} className="img-dim round-image" alt={pic} />
          <h4 style={{ marginLeft: '20px' }}>{name}</h4>
        </div>
      </div>
      
      <div className="lists-container mt-5">
      <div className="buttons-container">
        <div className="buttons-column">
          <button onClick={handleFeedbacksClick} className="btn_dark_bg text-white">
            Feedbacks
          </button>
          <button onClick={handleViewAnnouncementsClick} className="btn_dark_bg text-white">
            View Announcements
          </button>
          <button onClick={handleAddAnnouncementClick} className="btn_dark_bg text-white">
            Add Announcement
          </button>

          <button  className="btn_dark_bg text-white">
            Add Recipient
          </button>
          <button  className="btn_dark_bg text-white">
            Add Donor
          </button>


        </div>
      </div>
        <div className="list lists-containers">
          <DonorList />
        </div>
        <div className="list lists-containers">
        
          <RecipientList />
        </div>
      
      
      </div>
    </div>
  );
};

export default AdminPortal;
