import React from 'react';
import { useNavigate } from 'react-router-dom';
import DonorList from './DonorList';
import RecipientList from './RecipientList';
import '../App.css';
import { jwtDecode } from 'jwt-decode';

const AdminPortal = () => {
  const token = localStorage.getItem('token');
  const decodedToken = jwtDecode(token);
  const name = decodedToken.name;
  const pic = decodedToken.profilePicture;
  const navigate = useNavigate();
  console.log(decodedToken);

  const handleAddAnnouncementClick = () => {
    navigate('/add-announcement');
  };

  const handleViewAnnouncementsClick = () => {
    navigate('/announcement-list');
  };

  return (
    <div className="admin-portal all-screens-bg">
      <div className="profile-container">
        <div className="profile-info">
          <img src={`http://localhost:3001/uploads/${pic}`} className="img-dim round-image" alt={pic} />
          <h4>{name}</h4>
        </div>
        <div className="buttons-container">
          <button onClick={handleAddAnnouncementClick}>Add Announcement</button>
          <button onClick={handleViewAnnouncementsClick}>View Announcements</button>
        </div>
      </div>

      <div className="lists-container mt-5">
        <div className="list lists-containers">
          <h3 style={{ color: '#fff' }}>Donors</h3>
          <DonorList />
        </div>

        <div className="list lists-containers">
          <h3 style={{ color: '#fff' }}>Recipients</h3>
          <RecipientList />
        </div>
      </div>
    </div>
  );
};

export default AdminPortal;
