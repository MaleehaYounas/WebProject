import React, { useState } from 'react';

const AddAnnouncement = ({ onAdd }) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');

  const handleAdd = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:3001/admin/add-announcement', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          token: token,
        },
        body: JSON.stringify({
          title: title,
          content: content,
        }),
      });

      if (!response.ok) {
        throw new Error(`Failed to add announcement. Status: ${response.status}`);
      }

      const data = await response.json();
      onAdd(data);
      setTitle('');
      setContent('');
    } catch (error) {
      console.error('Error adding announcement:', error.message);
    }
  };

  return (
    <div>
      <h3 style={{ color: '#fff' }}>Add Announcement</h3>
      <div>
        <label>Title:</label>
        <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} />
      </div>
      <div>
        <label>Content:</label>
        <textarea value={content} onChange={(e) => setContent(e.target.value)} />
      </div>
      <button onClick={handleAdd}>Add Announcement</button>
    </div>
  );
};

export default AddAnnouncement;
