import React, { useState, useEffect } from 'react';

const AnnouncementList = ({ onDelete }) => {
  const [announcements, setAnnouncements] = useState([]);

  useEffect(() => {
    const fetchAnnouncements = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await fetch('http://localhost:3001/admin/get-all-announcements', {
          headers: {
            token: token,
          },
        });

        if (!response.ok) {
          throw new Error(`Failed to fetch announcements. Status: ${response.status}`);
        }

        const data = await response.json();
        setAnnouncements(data);
      } catch (error) {
        console.error('Error fetching announcements:', error.message);
      }
    };

    fetchAnnouncements();
  }, []);

  const handleDelete = async (announcementId) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`http://localhost:3001/admin/delete-announcement/${announcementId}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          token: token,
        },
      });
  
      if (!response.ok) {
        throw new Error(`Failed to delete announcement. Status: ${response.status}`);
      }
  
      // Assuming the onDelete function is used to update the state in the parent component
      onDelete(announcementId);
    } catch (error) {
      console.error('Error deleting announcement:', error.message);
    }
  };
  

  return (
    <div>
      <h3 style={{ color: '#fff' }}>Announcements</h3>
      <ul>
        {announcements.map((announcement) => (
          <li key={announcement._id}>
            {announcement.title} - {announcement.content}
            <button onClick={() => handleDelete(announcement._id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AnnouncementList;
