import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import "../App.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import SearchBar from './SearchBar';

const DonorList = () => {
  const [donors, setDonors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();
  const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchDonors = async () => {
      try {
      
        const response = await fetch('http://localhost:3001/admin/get-all-donors', {
          headers: {
            token: token,
          },
        });

        if (!response.ok) {
          throw new Error(`Failed to fetch donors. Status: ${response.status}`);
        }

        const data = await response.json();
        setDonors(data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching donors:', error.message);
        setLoading(false);
      }
    };

    fetchDonors();
  }, []);



  const handleSearch = async (searchTerm) => {
    try {
      setLoading(true);
    
      const response = await fetch(`http://localhost:3001/search/donor/${searchTerm}`, {
        headers: {
          token: token,
        },
      });
      if (!response.ok) {
        throw new Error(`Failed to fetch search results. Status: ${response.status}`);
      }
  
      const data = await response.json();
      console.log('Search results:', data);
  
      if (data.length === 1) {
        const donorId = data[0]._id;
        console.log('Navigating to recipient details:', donorId);
        navigate(`/donor-details/${donorId}`);
      } else if (data.length > 1) {
        // Handling the case when there are multiple results
        console.log('Multiple matching donors found. Display a list or choose the first one.');
      } else {
        console.log('No matching donors found');
      }
  
      setLoading(false);
    } catch (error) {
      console.error('Error searching donors:', error.message);
      setLoading(false);
    }
  };
  








  const handleDonorClick = (donorId) => {
    // Navigate to DonorDetails component with the donorId
    navigate(`/donor-details/${donorId}`);
  };

  return (
    <div>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <div>
          <h2 className='text-center p-1 heading-container'>Donors</h2>
          <SearchBar
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        handleSearch={handleSearch}
      />
          <ul style={{ listStyle: 'none', padding: 0 }}>
            {donors.map((donor, index) => (
              <React.Fragment key={donor.id}>
                <li
                  onClick={() => handleDonorClick(donor._id)}
                  className="donor-recipient-list-text"
                >
                  <strong>{donor.name}</strong> - {donor.email}- {donor.occupation}
                </li>
              </React.Fragment>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default DonorList;
