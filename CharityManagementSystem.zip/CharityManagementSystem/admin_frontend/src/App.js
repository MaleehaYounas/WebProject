// App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './Components/Home';
import NavBar from './Components/NavBar';
import Footer from './Components/Footer';
import Login from "./Components/Login";
import DonorList from "./Components/DonorList";
import AdminPortal from './Components/AdminPortal';
import DonorDetails from './Components/DonorDetails'; 
import RecipientDetails from './Components/RecipientDetails'; 
import AddAnnouncement from './Components/AddAnnouncementScreen';
import AnnouncementList from './Components/AnnouncementListScreen';
import RecipientFeedbackList from './Components/RecipientFeedbackList';
import DonorFeedbackList from './Components/DonorFeedbackList';
import Feedback from './Components/Feedback';
import RecipientFeedbackHome from './Components/ViewRecipientFeedback';
import DonorFeedbackHome from './Components/ViewDonorFeedback';

function App() {
  return (
    <Router>
      <div>
      <NavBar/>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/login" element={<Login />} />
          <Route path="/adminPortal" element={<AdminPortal />} />
          <Route path="/donorList" element={<DonorList />} />
          <Route path="/donor-details/:donorId" element={<DonorDetails />} /> 
          <Route path="/recipient-details/:recipientId" element={<RecipientDetails />} /> 
          <Route path="/add-announcement" element={<AddAnnouncement />} />
        <Route path="/announcement-list" element={<AnnouncementList />} />
        <Route path="/recipient-feedback-list" element={<RecipientFeedbackList />} />
        <Route path="/donor-feedback-list" element={<DonorFeedbackList />} />
        <Route path="/feedback" element={<Feedback />} />
        <Route path="/see-recipient-feedback" element={<RecipientFeedbackHome />} />
        <Route path="/see-donor-feedback" element={<DonorFeedbackHome />} />
    
        </Routes>
        <Footer />
      </div>
     
    </Router>
  );
}

export default App;
