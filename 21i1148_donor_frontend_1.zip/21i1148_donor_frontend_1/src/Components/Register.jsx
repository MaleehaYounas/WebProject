import React from 'react';
import { Link } from 'react-router-dom';
import registerImage from '../Images/register_icon.png';
import donorLogo from '../Images/donor_hand.png';
import recipientLogo from '../Images/recipient_hand.png';

const RegisterPage = () => {
  return (
    <section className="background3" style={{ height: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>

        <img src={registerImage} className="center" style={{ height: '84px', width: '76px' , marginBottom: '20px'}} alt="" />

      <h5 className="mt-4 text-center text-white mb-2">Register</h5>

      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <div className="col-lg-6 col-md-6">
          {/* Register as Donor button */}
          <Link to="/registerAsDonor" style={{ textDecoration: 'none' }}>
          <button className="btn_bg center" style={{ width: '200px', padding: '10px', marginBottom:'20px' }}>
            <img src={donorLogo} alt="Donor Logo" style={{ height: '20px', width: '20px', marginRight: '10px' }} />
              Register as Donor
            </button>
          </Link>
        </div>
        <div className="col-lg-6 col-md-6">
          {/* Register as Recipient button */}
          <Link to="/registerAsRecipient" style={{ textDecoration: 'none' }}>
          <button className="btn_bg center" style={{ width: '230px', padding: '10px' }}>
              <img src={recipientLogo} alt="Recipient Logo" style={{ height: '20px', width: '20px', marginRight: '10px' }} />
              Register as Recipient
            </button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default RegisterPage;

//registerdonor


//   return (
//     <section className="background3">
//       <div className="container mt-5">
//         <div className="row justify-content-center">
//           <div className="col-md-6">
//             <form onSubmit={handleSubmit} className="rounded p-4 shadow-lg bg-light">
//               <h2 className="text-center mb-4 text-primary">Registeration as Donor</h2>

//          <div className="mb-3">
//         <label className="form-label">Name:</label>
//         <input type="name" name="name" className="form-control" onChange={handleInputChange} />
//       </div>

//       <div className="mb-3">
//         <label className="form-label">Email:</label>
//         <input type="email" name="email" className="form-control" onChange={handleInputChange} />
//       </div>

//       <div className="mb-3">
//         <label className="form-label">Password:</label>
//         <input type="password" name="password" className="form-control" onChange={handleInputChange} />
//       </div>

//       <div className="mb-3">
//         <label className="form-label">CNIC:</label>
//         <br></br>
//         <input type="text" name="cnic" className="form-control" onChange={handleInputChange} />
//       </div>

//       <div className="mb-3">
//         <label className="form-label">Occupation:</label>
//         <input type="text" name="occupation" className="form-control" onChange={handleInputChange} />
//       </div>

//       <div className="mb-3">
//         <label className="form-label">Phone:</label>
//         <input type="tel" name="phone" className="form-control" onChange={handleInputChange} />
//       </div>

//       <div className="mb-3">
//         <label className="form-label">Address:</label>
//         <textarea name="address" className="form-control" onChange={handleInputChange}></textarea>
//       </div>

//       <div className="mb-3">
//         <label className="form-label">Religion:</label>
//         <input type="text" name="religion" className="form-control" onChange={handleInputChange} />
//       </div>

//       <div className="mb-3">
//         <label className="form-label">Profile Picture:</label>
//         <input type="file" name="profilePicture" className="form-control" onChange={handleFileChange} />
//       </div>

//       <div className="regbtncontainer">
//       <button type="submit" className="btn btn-primary">Back</button>
//       <button type="submit" className="btn btn-primary">Register</button>
//       </div>
//       </form>
//           </div>
//         </div>
//       </div>
//     </section>
//   );
// return(
// <div>
     
//       <section className="background3">
//         <div className="row m-0 text-white text">
//           <div className="col-md-6">
//            <form onSubmit={handleSubmit} className="rounded p-4">
//           <h2 className="text-left mb-4 text-primary text-white">Registeration as Donor</h2>
//           <div className="mb-3">
//          <label className="form-label">Name:</label>
//          <input type="name" name="name" className="form-control" onChange={handleInputChange} />
//        </div>

//        <div className="mb-3">         <label className="form-label">Email:</label>
//          <input type="email" name="email" className="form-control" onChange={handleInputChange} />
//        </div>

//        <div className="mb-3">
//          <label className="form-label">Password:</label>
//          <input type="password" name="password" className="form-control" onChange={handleInputChange} />
//        </div>
//        <div className="mb-3">
//          <label className="form-label">CNIC:</label>
//          <br></br>
//          <input type="text" name="cnic" className="form-control" onChange={handleInputChange} />
//        </div>

//        <div className="mb-3">
//          <label className="form-label">Occupation:</label>
//          <input type="text" name="occupation" className="form-control" onChange={handleInputChange} />
//        </div>

//        <div className="mb-3">
//          <label className="form-label">Phone:</label>
//          <input type="tel" name="phone" className="form-control" onChange={handleInputChange} />
//        </div>

//        <div className="mb-3">
//          <label className="form-label">Address:</label>
//          <textarea name="address" className="form-control" onChange={handleInputChange}></textarea>
//        </div>

//        <div className="mb-3">
//          <label className="form-label">Religion:</label>
//          <input type="text" name="religion" className="form-control" onChange={handleInputChange} />
//        </div>

//        <div className="mb-3">
//          <label className="form-label">Profile Picture:</label>
//          <input type="file" name="profilePicture" className="form-control" onChange={handleFileChange} />
//        </div>

//        <div className="regbtncontainer">
//        <button type="submit" className="btn btn-primary">Back</button>
//          <button type="submit" className="btn btn-primary">Register</button>
//          </div>
//           </form>
//            </div>
//         </div>

//       </section>

//     </div>
//   );