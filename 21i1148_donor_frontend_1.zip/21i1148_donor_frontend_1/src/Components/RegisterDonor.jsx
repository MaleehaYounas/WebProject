import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Link, useLocation } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../App.css';


const DonorRegisteration = () => {
  const [formData, setFormData] = useState({
    name: '',
    role: 'donor',
    email: '',
    password: '',
    cnic: '',
    occupation: '',
    profilePic: null,
    phoneNum: '',
    address: '',
    religion: '',
  });

  const handleInputChange = (e) => 
  {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };
  const navigate = useNavigate();
  const handleFileChange = (e) => {
    const { name, files } = e.target;
    setFormData({ ...formData, [name]: files[0] });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const form = new FormData();
    Object.entries(formData).forEach(([key, value]) => {
      form.append(key, value);
    });
    
    console.log("Donor data:", form);
    try {
      const response = await fetch('http://localhost:3001/donor/create', {
        method: 'POST',
        body:  new FormData(e.target),

      });

      if (response.ok) {
        const result = await response.json();
        console.log('Donor created:', result);

        // When successful, login page will be opened for the donor
        setTimeout(() => {
          navigate('/login');
        }, 1000); // delay present
      }
      
      else {
        const error = await response.json();
        console.error('Unable to register the recipient', error);
      }
    } catch (error) {
      console.error('Error:', error);
      // Handle network error or other issues
    }
  };

return (
  <div>
    <section className="background3">
    <form onSubmit={handleSubmit} className="rounded p-4">
      <div className="row m-0 text-white text">
        <div className="col-md-6">
            <h2 className="text-left mb-4 text-primary text-white">Registration as Donor</h2>
            <div className="mb-3">
              <label className="form-label">Name:</label>
              <input type="name" name="name" className="form-control" onChange={handleInputChange} style={{ width: '100%' }} />
            </div>

            <div className="mb-3">
              <label className="form-label">Email:</label>
              <input type="email" name="email" className="form-control" onChange={handleInputChange} style={{ width: '100%' }}/>
            </div>

            <div className="mb-3">
              <label className="form-label">Password:</label>
              <input type="password" name="password" className="form-control" onChange={handleInputChange} style={{ width: '100%' }}/>
            </div>

            <div className="mb-3">
              <label className="form-label">CNIC:</label>
              <br></br>
              <input type="text" name="cnic" className="form-control" onChange={handleInputChange} style={{ width: '100%' }} />
            </div>

            <div className="mb-3">
              <label className="form-label">Occupation:</label>
              <input type="text" name="occupation" className="form-control" onChange={handleInputChange} style={{ width: '100%' }}/>
            </div>   
        </div>

        <div className="col-md-6">
          <br></br>
          <br></br>
          <br></br>
          <div className="mb-3">      
                      
            <label className="form-label">Profile Picture:</label>
            <input type="file" name="profilePicture" className="form-control" onChange={handleFileChange} style={{ width: '100%' }}/>
          </div>

          <div className="mb-3">
              <label className="form-label">Phone:</label>
              <input type="tel" name="phone" className="form-control" onChange={handleInputChange} style={{ width: '100%' }}/>
            </div>

            <div className="mb-3">
              <label className="form-label">Address:</label>
              <textarea name="address" className="form-control" onChange={handleInputChange} style={{ width: '100%' }}></textarea>
            </div>

            <div className="mb-3">
              <label className="form-label">Religion:</label>
              <input type="text" name="religion" className="form-control" onChange={handleInputChange} style={{ width: '100%' }} />
            </div>

            </div>
            <br></br>
            <br></br>
            <br></br>
      </div>
      <br></br>    
      <div className='text-center regbtncontainer'>
                 <div>
                  <Link to="/register">
                    <button className="btn_bg text" style={{ padding: '27% 45% 27% 45%' }}>
                      Back
                    </button>
                  </Link>
                </div>
                <div className="me-5">
                  <Link to="/register">
                    <button className="btn_bg text me-4" style={{ padding: '15% 40% 15% 40%' }}>
                      Register
                    </button>
                  </Link>
                </div>
                </div>
      </form>
    </section>
  </div>
);


};

export default DonorRegisteration;
