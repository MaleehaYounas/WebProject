import React from 'react';
import DonorList from './DonorList';
import RecipientList from './RecipientList';
import '../App.css';
import { jwtDecode } from 'jwt-decode';

const AdminPortal = () => {
  const token = localStorage.getItem('token');
  const decodedToken = jwtDecode(token);
  const name = decodedToken.name;
  const pic = decodedToken.profilePicture;
  console.log(decodedToken);

  return (
    <div className="admin-portal all-screens-bg">
      <div className="profile-container">
        <img src={`http://localhost:3001/uploads/${pic}`} className="img-dim round-image" alt={pic} />
        <h4>{name}</h4>
      </div>

      <div className="lists-container mt-5">
        <div className="list lists-containers">
          <h3 style={{ color: '#fff' }}>Donors</h3>
          <DonorList />
        </div>

        <div className="list lists-containers">
          <h3 style={{ color: '#fff' }}>Recipients</h3>
          <RecipientList />
        </div>
      </div>
    </div>
  );
};

export default AdminPortal;
