// import logo from './logo.svg';
// import './App.css';

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );
// }

// export default App;
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './Components/Home';
import NavBar from './Components/NavBar';
import Footer from './Components/Footer';
import Login from "./Components/Login";
import DonorList from "./Components/DonorList";
import AdminPortal from './Components/AdminPortal';
import DonorDetails from './Components/DonorDetails'; 
import RecipientDetails from './Components/RecipientDetails'; 
import DonorRegisteration from './Components/RegisterDonor';
import RegisterPage from './Components/Register';
import DonorPortal from './Components/DonorPortal';

function App() {
  return (
    <Router>
      <div>
        <NavBar />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/login" element={<Login />} />
          <Route path="/adminPortal" element={<AdminPortal />} />
          <Route path="/donorList" element={<DonorList />} />
          <Route path="/donor-details/:donorId" element={<DonorDetails />} /> 
          <Route path="/recipient-details/:recipientId" element={<RecipientDetails />} /> 
          <Route path="/register" element={< RegisterPage/>} />
          <Route path="/registerAsDonor" element={<DonorRegisteration/>} />
          <Route path="/donorPortal" element={<DonorPortal/>} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
