import React, { useState, useEffect } from "react";
import "../App.css"; // Import the shared CSS file
import "bootstrap/dist/css/bootstrap.min.css";
import { Modal, Button } from "react-bootstrap"; // Import Bootstrap Modal and Button
import RateReviewIcon from "@mui/icons-material/RateReview";

const DonorList = () => {
  const [donors, setDonors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [feedbackText, setFeedbackText] = useState("");
  const [feedbackSuccess, setFeedbackSuccess] = useState(false); // New state variable
  const [searchTerm, setSearchTerm] = useState(""); // New state variable for search term

  useEffect(() => {
    const fetchDonors = async () => {
      try {
        const token = localStorage.getItem("token");
        // Use the search term to fetch donors
        const response = await fetch(
          `http://localhost:3003/recipient/searchDonor`,
          {
            method: "POST",
            headers: {
              token: token,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              name: searchTerm,
            }),
          }
        );

        if (!response.ok) {
          throw new Error(`Failed to fetch donors. Status: ${response.status}`);
        }

        const data = await response.json();
        setDonors(data.donors);

        setLoading(false);
      } catch (error) {
        console.error("Error fetching donors:", error.message);
        setLoading(false);
      }
    };

    fetchDonors();
  }, [searchTerm]);

  const handleFeedbackButton = () => {
    setShowModal(true);
    setFeedbackSuccess(false);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setFeedbackText("");
    setFeedbackSuccess(false);
  };

  const handleSendFeedback = async () => {
    try {
      const token = localStorage.getItem("token");
      console.log("Token:", token);

      const response = await fetch("http://localhost:3003/recipient/feedback", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          token: token,
        },

        body: JSON.stringify({
          message: feedbackText,
        }),
      });

      if (!response.ok) {
        throw new Error(`Failed to send feedback. Status: ${response.status}`);
      }

      console.log("Feedback sent successfully");
      setFeedbackSuccess(true);
    } catch (error) {
      console.error("Error sending feedback:", error.message);
      setFeedbackSuccess(false); // Set feedback success status
    }
  };

  const handleInputChange = (e) => {
    //     const { name, value } = e.target;
    //     setSearchTerm((prevParams) => ({
    //       ...prevParams,
    //       [name]: value,
    //     }));
    setSearchTerm(e.target.value);
  };

  return (
    <section style={{ paddingTop: "40px", backgroundColor: "#4B7F9C" }}>
      <div className="container">
        <div className="mb-3">
          <input
            type="text"
            className="form-control"
            placeholder="Search by donor name"
            name="searchTerm"
            value={searchTerm}
            onChange={handleInputChange}
          />
        </div>

        <div className="row justify-content-center"style={{ backgroundColor: '#D9D9D9 !important' }}>
          <div className="col-md-8"style={{ backgroundColor: '#D9D9D9 !important' }}>
            {loading ? (
              <p>Loading...</p>
            ) : (
<ul className="list-group" style={{ backgroundColor: '#D9D9D9 !important' }}>
  {donors.map((donor) => (
    <li
      key={donor._id}
      className="list-group-item d-flex justify-content-between align-items-center"
    >
      <div>
        <h5 className="mb-1">
          <strong>{donor.name}</strong>
        </h5>
        <p className="mb-1">{donor.email}</p>
        <p className="mb-1">{donor.occupation}</p>
      </div>
      <button
        type="button"
        className="btn btn-primary"
        style={{ backgroundColor: "#4B7F9C", border: "none" }}
      >
        Send Request
      </button>
    </li>
  ))}
</ul>

            )}
            {/* Feedback button */}
            <button
              type="button"
              className="btn btn-success feedback-button"
              style={{ marginTop: "20px", marginLeft: "800px", width: "170px", backgroundColor: "#D9D9D9", color:'black' }}
              onClick={handleFeedbackButton}
            >
              <RateReviewIcon />
              Give Feedback
            </button>
          </div>
        </div>
      </div>
      {/* Modal for feedback */}
      <Modal show={showModal} onHide={handleCloseModal}>
        <Modal.Header closeButton>
          <Modal.Title>Give Feedback About Our App</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <textarea
            className="form-control"
            rows="4"
            placeholder="Enter your feedback here"
            value={feedbackText}
            onChange={(e) => setFeedbackText(e.target.value)}
          />
          {feedbackSuccess && (
            <p className="text-success">Feedback sent successfully!</p>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseModal}>
            Close
          </Button>
          <Button variant="primary" onClick={handleSendFeedback}>
            Send
          </Button>
        </Modal.Footer>
      </Modal>
      .
    </section>
  );
};

export default DonorList;
