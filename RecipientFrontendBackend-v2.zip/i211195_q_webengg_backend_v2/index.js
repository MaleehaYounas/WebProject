const express = require("express")
const mongoose  =require("mongoose")
const multer = require('multer');

const cors = require("cors")
const upload = require("express-fileupload")
const bodyparser= require("body-parser");
const app = express();

app.use(cors())
app.use(bodyparser.json());
app.use(express.json())
require("dotenv").config()
app.use(upload())
app.use("/uploads" , express.static("uploads"))



//const SearchRouter = require("./Routes/SearchRoutes");
const RecipientRouter = require("./Routes/RecipientRoutes");
app.use("/recipient" ,  RecipientRouter)

const DonorRouter = require("./Routes/DonorRoutes");
app.use("/donor" ,  DonorRouter)

app.listen(3003);
app.use(cors());



mongoose.connect(process.env.MONGODB_STRING).then(()=>{
    console.log("Connected")
}).catch(err=>{
    console.log(err)
})
