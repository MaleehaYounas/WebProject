import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import '../App.css';
import { jwtDecode } from 'jwt-decode';

const DonorDetails = () => {
  const { donorId } = useParams();
  console.log('URL donorId:', donorId); 
  const [donor, setDonor] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isBlocked, setIsBlocked] = useState(false);
  const token = localStorage.getItem('token');
  const decodedToken = jwtDecode(token);
  const name = decodedToken.name;
  const picture = decodedToken.profilePicture;

  useEffect(() => {
    const fetchDonorDetails = async () => {
      try {
        // const token = localStorage.getItem('token');
        const response = await fetch(`http://localhost:3001/donor/getDonorbyId/${donorId}`, {
          headers: {
            // token: token,
            Authorization: `Bearer ${token}`,
          },
        });

        if (!response.ok) {
          throw new Error(`Failed to fetch donor details. Status: ${response.status}`);
        }

        const data = await response.json();
        setDonor(data);
        setIsBlocked(data.isBlocked);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching donor details:', error.message);
        setLoading(false);
      }
    };

    fetchDonorDetails();
  }, [donorId]);

  const handleBlockToggle = async () => {
    try {
      const token = localStorage.getItem('token');
      const action = isBlocked ? 'unblock' : 'block';

      const response = await fetch(`http://localhost:3001/donor/${action}-user/${donorId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          token: token,
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to ${action} donor. Status: ${response.status}`);
      }

      setIsBlocked(!isBlocked);
    } catch (error) {
      console.error(`Error ${isBlocked ? 'unblocking' : 'blocking'} donor:`, error.message);
    }
  };

  return (
    <div className="all_screen_padding all-screens-bg">
      <div className="profile-container">
        <div className="profile-info">
        <img src={`http://localhost:3001/uploads/${picture}`} className="img-dim round-image" alt={picture} />
          <h4 style={{ marginLeft: '20px' }}>{name}</h4>
        </div>
      </div>
      <div className='user-details-container'>
        <h2>Donor Profile</h2>
        {loading ? (
          <p>Loading...</p>
        ) : donor ? (
          <div className='user-details-content'>
            <div className='user-details-column'>
              <p><strong>Name:</strong> {donor.name}</p>
              <p><strong>Email:</strong> {donor.email}</p>
              <p><strong>Phone:</strong> {donor.phone}</p>
              <p><strong>Address:</strong> {donor.address}</p>
              <p><strong>Occupation:</strong> {donor.occupation}</p>
              <p><strong>Religion:</strong> {donor.religion}</p>
            </div>
          </div>
        ) : (
          <p>Donor not found</p>
        )}
      </div>
    </div>
  );
 
};

export default DonorDetails;


