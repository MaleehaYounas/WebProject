// import React, { useState, useEffect} from 'react'
// DonorFeedback.jsx

import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

const DonorFeedback = () => {
  const navigate = useNavigate();
  const [feedback, setFeedback] = useState('');

  const handleGiveFeedback = async () => {
    // Implement the logic to send feedback to the backend
    try {
      const response = await fetch('http://localhost:3001/donors/giveFeedback', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify({ message: feedback }),
      });

      if (response.ok) {
        console.log('Feedback submitted successfully');
        // You can redirect or update the UI as needed
      } else {
        console.error('Error submitting feedback');
      }
    } catch (error) {
      console.error('Error submitting feedback:', error);
    }
  };

  const handleSeeAllFeedback = async () => {
    // Implement the logic to fetch all feedbacks from the backend
    try {
      const response = await fetch('/api/donors/getFeedbacks', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('token')}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        console.log('All Feedbacks:', data.feedbacks);
        // Update the UI to display feedbacks
      } else {
        console.error('Error fetching feedbacks');
      }
    } catch (error) {
      console.error('Error fetching feedbacks:', error);
    }
  };

  return (
    <div className="donor-portal all-screens-bg">
        <div className="container-center">
      <div className="feedback-form" >
        <h2 style={{color: 'rgb(15, 77, 99)'}}>Donor Feedback </h2>
        <div>
          <label htmlFor="feedback" style={{color: 'rgb(15, 77, 99)'}}><b>Enter Feedback:</b></label>
          <textarea
            id="feedback"
            value={feedback}
            onChange={(e) => setFeedback(e.target.value)}
          ></textarea>
        </div>
        <Link to="/donorPortal">
        <button onClick={handleGiveFeedback} className='btn_bg text'>Submit Feedback</button>
        </Link>
      </div>
    </div>
    </div>
    
  );
  
};

export default DonorFeedback;
