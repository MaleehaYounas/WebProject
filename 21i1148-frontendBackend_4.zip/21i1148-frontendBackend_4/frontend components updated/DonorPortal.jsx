import React from "react";
import { useNavigate } from "react-router-dom";
import { jwtDecode } from 'jwt-decode';

const DonorPortal = () => {
  const navigate = useNavigate();
  const token = localStorage.getItem('token');
  const decodedToken = jwtDecode(token);
  const name = decodedToken.name;
  const donorId = decodedToken.donorId;
  const picture = decodedToken.profilePicture;
  console.log(decodedToken);

  const handleChooseRecipientClick = () => {
    // navigate('/recipient-details/${recipientId}');
    navigate('/recipientList');
  };

  const handleChatClick = () => {
    navigate('/chatrecipient');
  };

  const handleTrackDonationClick = () => {
    navigate('/trackDonation');
  };

  const handleGiveFeedbackClick = () => {
    navigate('/giveFeedback');
  };

  const handleSeeAllFeedbackClick = () => {
    navigate('/seeFeedback');
  };

  const handleMyProfileClick = () => {
    // navigate('/donor-details/:donorId')
    navigate(`/donor-details/${decodedToken.donorId}`);
  }
  return (
  <div className="donor-portal all-screens-bg">
  <div className="profile-container" style={{flexDirection: 'column'}}>
    <div className="profile-info" style={{flexDirection: 'column'}}>
      <img src={`http://localhost:3001/uploads/${picture}`} className="img-dim round-image" alt={picture} />
      <h4 style={{ marginLeft: '20px' }}>{name}</h4>
    </div>
    <div className="buttoncontainerDonor">

      <br></br>
    <div className="buttons-container" style={{ marginLeft: 'auto', marginRight: '20px', flexDirection:'column', gap: '10px'}}>
    <button onClick={handleMyProfileClick} className='btn_dark_bg text-white' style={{ padding: '5px 15px 5px 15px', width: '100%'}}>My Profile</button>
      <br></br>
      <button onClick={handleChooseRecipientClick} className='btn_dark_bg text-white' style={{ padding: '5px 15px 5px 15px', width: '100%'}}>Choose Recipient</button>
      <br></br>
      <button onClick={handleChatClick} className='btn_dark_bg text-white' style={{ padding: '10px 30px 10px 30px', width: '100%'}}>Chat with Recipient</button>
      <br></br>
      <button onClick={handleTrackDonationClick} className='btn_dark_bg text-white' style={{ padding: '10px 30px 10px 30px', width: '100%'}}>Track my Donation</button>
      <br></br>

      <button
        onClick={() => navigate('/donorFeedback')}
        className='btn_dark_bg text-white'
        style={{ padding: '10px 30px 10px 30px', width: '100%'}}
      >
        Give Feedback
      </button>
      <br />
      <button
        onClick={() => navigate('/donorFeedback')}
        className='btn_dark_bg text-white'
        style={{ padding: '10px 30px 10px 30px', width: '100%'}}
      >
        See Feedbacks
      </button>
    </div>
    </div>
    </div>
</div>
);
};

export default DonorPortal;

