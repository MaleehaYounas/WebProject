const Donor = require("../models/Donor.schema");
const Recipient = require("../models/Recipient.schema");
const jwt = require("jsonwebtoken");
const Feedback = require("../models/Feedback.schema");


let getAllDonors = async (req, res) => {
    try {
        // Assuming req.query.role is used to filter by role
        
        const roleFilter = req.query.role;

        // Constructing the query based on the role filter
        const query = roleFilter ? { role: roleFilter } : {};

        let donors = await Donor.find({});
        res.status(200).json(donors);
    } catch (err) {
        res.status(500).json({ "Message": "Error", err: err });

    }
};

let getDonorById = async (req, res) => {
    let id = req.params.id;
    try {
        let donor = await Donor.findOne({ _id: id });
        if (donor) {
            res.status(200).json(donor);
        } else {
            res.status  (404).json({ "Message": "Donor not found" });
        }
    } catch (err) {
        res.status(500).json({ "Message": "Error", err: err });
    }
};

let createDonor = async (req, res) => {
    let data = req.body;
    let { profilePicture } = req.files;

    let profilePicturePath = Date.now().toString() + profilePicture.name;

    try {
        profilePicture.mv("./uploads/" + profilePicturePath);

        let newDonor = await Donor.create({
            name: data.name,
            email: data.email,
            password: data.password,
            phone: data.phone,
            address: data.address,
            occupation: data.occupation,
            religion: data.religion,
            profilePicture: profilePicturePath,
            isBlocked: false,
            donationHistory: []
        });

        res.status(201).json(newDonor);
    } catch (err) {
        res.status(500).json({ "Message": "There was some error", err });
    }
};

let updateDonorById = async (req, res) => {
    let id = req.params.id;
    let data = req.body;

    try {
        let donor = await Donor.findByIdAndUpdate(id, data);
        if (donor) {
            res.status(200).json(donor);
        } else {
            res.status(404).json({ "Message": "Donor not found" });
        }
    } catch (err) {
        res.status(500).json({ "Message": "Error", err: err });
    }
};

let deleteDonorById = async (req, res) => {
    let id = req.params.id;
    try {
        let donor = await Donor.findByIdAndDelete(id);
        if (donor) {
            res.status(200).json(donor);
        } else {
            res.status(404).json({ "Message": "Donor not found" });
        }
    } catch (err) {
        res.status(500).json({ "Message": "Error", err: err });
    }
};

const giveFeedback = async (req, res) => {
    try{
       // const {message} = req.body;
        // const uName = req.body;
        // const uID = req.body;
        // const role = req.body;
        console.log('Request Body:', req.body); 
        const {userName, userId, userRole, message} = req.body;

        const feedback = new Feedback({
            // userName: uName,
            // userId: uID,
            // userRole: role,
            // message,
            userName,
            userId,
            userRole,
            message,
        });

        const newFeedback = await feedback.save(); //inorder to save the given feedback

        res.status(201).json(newFeedback);
    }catch(error)
    {
        console.error(error);
        // res.status(500).json({error: 'Error while giving feedback'});
        console.error("Error while giving feedback:", error);
        res.status(500).json({ error: 'Error while giving feedback' });
    }
};

// const getFeedbacks = async (req, res) =>{
//     try{
//         const feedbacks = await Feedback.find({});
//         res.status(201).json({"Message":"Fetching all the Feedbacks of the App", feedbacks});
//     }catch(error)
//     {
//         console.error(error);
//         res.status(404).json({"Message":"Error while fetching all the feedbacks", error});
//     }
// };

const getFeedbacks = async (req, res) => {
    try {
        // Assuming req.user.role is used to determine the user's role
        const userRole = req.user.role;

        // Constructing the query based on the user's role
        const query = userRole ? { userRole } : {};

        const feedbacks = await Feedback.find(query);
        res.status(200).json({ message: "Fetching all the Feedbacks", feedbacks });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Error while fetching feedbacks", error });
    }
};

module.exports = getFeedbacks;



    const getAllRecipients = async (req, res) => {
        try {
            // Assuming req.user.role is used to determine the user's role
            if (req.user.role === "admin") {
                // Find all recipients in the system
                const recipients = await Recipient.find();
                res.status(200).json(recipients);
            } else {
                res.status(403).json({ "Message": "You are not authorized for this action" });
            }
        } catch (err) {
            console.error(err);
            res.status(500).json({ "Message": "Server error" });
        }
    };


module.exports = {
    getAllDonors,
    getDonorById,
    createDonor,
    updateDonorById,
    deleteDonorById,
    giveFeedback,
    getFeedbacks,
    getAllRecipients,
};