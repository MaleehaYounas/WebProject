const {createDonor, getAllDonors, getDonorById, updateDonorById, deleteDonorById, giveFeedback, getFeedbacks, getAllRecipients} = require("../Controller/DonorController")

const express = require("express");
const { AuthenticateUser, Login} = require("../utils");
const router2 = express.Router();

router2.post("/login", Login);
router2.get("/" ,getAllDonors)
router2.get("/getDonorbyId/:id" ,getDonorById)
router2.post("/create" , createDonor)
router2.patch("/:id" , updateDonorById)
router2.delete("/:id" ,  deleteDonorById)
router2.post("/appfeedback", giveFeedback)
router2.get("/getappfeedbacks", getFeedbacks)
// router2.get("/getAllRecipients" , getAllRecipients)

module.exports = router2;

// const express = require("express");
// const { AuthenticateUser } = require("../utils");
// const { createDonor, getAllDonors, getDonorById, updateDonorById, deleteDonorById, giveFeedback, getFeedbacks, getAllRecipients } = require("../Controller/DonorController");

// const router2 = express.Router();

// router2.post("/login", Login);
// router2.get("/", getAllDonors);
// router2.get("/get-all-recipients", AuthenticateUser, getAllRecipients); // Moved this route above the "/:id" route
// router2.get("/:id", getDonorById);
// router2.post("/create", createDonor);
// router2.patch("/:id", updateDonorById);
// router2.delete("/:id", deleteDonorById);
// router2.post("/appfeedback", giveFeedback);
// router2.post("/getfeedbacks", getFeedbacks);

// module.exports = router2;
