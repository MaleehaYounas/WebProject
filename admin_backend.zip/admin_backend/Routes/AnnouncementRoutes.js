const { getAllAnnouncements, addAnnouncement, deleteAnnouncement} = require("../Controller/AnnouncementController")

const express = require("express");
const { AuthenticateUser } = require("../utils");
const router = express.Router();
router.get("/get-all-announcements", getAllAnnouncements)
router.post("/add-announcement",AuthenticateUser,addAnnouncement)
router.delete("/delete-announcement/:id",AuthenticateUser,deleteAnnouncement)

module.exports = router;