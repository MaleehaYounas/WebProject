const Feedback  = require('../models/Feedback.schema');

// Get all feedback for donors
const getDonorFeedback = async (req, res) => {
    try {
      const donorFeedback = await Feedback.find({ userRole: 'donor' }).sort({ createdAt: -1 });
      res.json(donorFeedback);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Server error' });
    }
  };
  
  // Get all feedback for recipients
  const getRecipientFeedback = async (req, res) => {
    try {
      const recipientFeedback = await Feedback.find({ userRole: 'recipient' }).sort({ createdAt: -1 });
      res.json(recipientFeedback);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Server error' });
    }
  };
  

  
// Reply to feedback
const replyToFeedback = async (req, res) => {
    try {
      // Check if the user is 'admin'
      if (req.role !== 'admin') {
        return res.status(403).json({ message: 'You are not authorized for this action' });
      }
  
      const { id } = req.params;
      const { reply } = req.body;
  
      const feedback = await Feedback.findById(id);
      if (!feedback) {
        return res.status(404).json({ message: 'Feedback not found' });
      }
  
      feedback.reply = reply;
      await feedback.save();
  
      res.json(feedback);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Server error' });
    }
  };
  
  // Delete feedback
  const deleteFeedback = async (req, res) => {
    try {
      // Check if the user is 'admin'
      if (req.role !== 'admin') {
        return res.status(403).json({ message: 'You are not authorized for this action' });
      }
  
      const { id } = req.params;
      const deletedFeedback = await Feedback.findByIdAndDelete(id);
  
      if (deletedFeedback) {
        res.json({ message: 'Feedback deleted' });
      } else {
        res.status(404).json({ message: 'Feedback not found' });
      }
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Server error' });
    }
  };

module.exports= {
    getDonorFeedback,
    getRecipientFeedback,
    replyToFeedback,
    deleteFeedback

};


