const Donor = require("../models/Donor.schema")
const Recipient = require("../models/Recipient.schema")
const Admin = require("../models/Admin.schema")
const fs = require('fs');
const path = require('path');
const jwt = require("jsonwebtoken")
const blockUser = async (req, res) => {
    try {
        // Check if the user is  'admin'
        if ( req.role === "admin") {
            const { id } = req.params;

            // Check if the user exists
            const donor = await Donor.findById(id);
            const recipient = await Recipient.findById(id);
            if (donor) {
                donor.isBlocked = true;
                await donor.save();
                res.status(200).json({ "Message": "Donor blocked" });
            }
            else if(recipient)
            {
                recipient.isBlocked = true;
                await recipient.save();
                res.status(200).json({ "Message": "Recipient blocked" });
            }
   
           
           
        } else {
            res.status(403).json({ "Message": "You are not authorized for this action" });
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ "Message": "Server error" });
    }
};

const unBlockUser = async (req, res) => {
    try {
        // Check if the user is  'admin'
        if ( req.role === "admin") {
            const { id } = req.params;

            // Check if the user exists
            const donor = await Donor.findById(id);
            const recipient = await Recipient.findById(id);
            if (donor) {
                donor.isBlocked = false;
                await donor.save();
                res.status(200).json({ "Message": "Donor blocked" });
            }
            else if(recipient)
            {
                recipient.isBlocked = false;
                await recipient.save();
                res.status(200).json({ "Message": "Recipient blocked" });
            }
   
           
           
        } else {
            res.status(403).json({ "Message": "You are not authorized for this action" });
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ "Message": "Server error" });
    }
};


const updateRecipientStatus = async (req, res) => {
    try {
        // Check if the user is  'admin'
        if ( req.role === "admin") {
            const { id } = req.params;

            // Check if the user exists
            const recipient = await Recipient.findById(id);
           if( recipient.isNeedFulfilled == false)
            {
                recipient.isNeedFulfilled = true;
                await recipient.save();
                res.status(200).json({ "Message": "Recipient need fulfilled" });
            }
           else if(recipient.isNeedFulfilled == true)
           {
            recipient.isNeedFulfilled = false;
                await recipient.save();
                res.status(200).json({ "Message": "Recipient need not fulfilled" });
           }
           
        } else {
            res.status(403).json({ "Message": "You are not authorized for this action" });
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ "Message": "Server error" });
    }
};

const getAllRecipients = async (req, res) => {
    try {
        
        if (req.role == "admin") {
            // Find all recipients in the system
            const recipients = await Recipient.find();
            res.status(200).json(recipients);
        } else {
            res.status(403).json({ "Message": "You are not authorized for this action" });
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ "Message": "Server error" });
    }
};

const getAllDonors = async (req, res) => {
    try {
        
        if (req.role == "admin") {
            // Find all donors in the system
            const donors = await Donor.find();
            res.status(200).json(donors);
        } else {
            res.status(403).json({ "Message": "You are not authorized for this action" });
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ "Message": "Server error" });
    }
};
const getAdmin = async (req, res) => {
    try {
        
        if (req.role == "admin") {
            
            const admin = await Admin.find();
            res.status(200).json(admin);
        } else {
            res.status(403).json({ "Message": "You are not authorized for this action" });
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ "Message": "Server error" });
    }
};
let getDonorById = async (req, res) => {
    let id = req.params.id;
    try {
        let donor = await Donor.findOne({ _id: id });
        if (donor) {
            res.status(200).json(donor);
        } else {
            res.status  (404).json({ "Message": "Donor not found" });
        }
    } catch (err) {
        res.status(500).json({ "Message": "Error", err: err });
    }
};
let getRecipientById = async (req, res) => {
    let id = req.params.id;
    try {
        let recipient = await Recipient.findOne({ _id: id });
        if (recipient) {
            res.status(200).json(recipient);
        } else {
            res.status(404).json({ "Message": "Recipient not found" });
        }
    } catch (err) {
        res.status(500).json({ "Message": "Error", err: err });
    }
};
let createAdmin = (req, res) => {
    let data = req.body;
    console.log(req.files)
    let { profilePicture } = req.files;
    console.log(profilePicture)

    let path = Date.now().toString() + profilePicture.name;
    profilePicture.mv("./uploads/" + path)
    Admin.create({
        email: data.email,
        password: data.password,
        name: data.name,
        phone: data.phone,
        role: data.role,
        cnic: data.cnic,
        profilePicture: path
    }).then(data => {
        res.status(201).json(data)
    }).catch(err => {
        res.status(500).json({ "Message": "There was Some Error" })
    })
}


let Login = async (req, res) => {
    let { email, password } = req.body;
    console.log(password)
    console.log(req.body)
    try {
        let recipient = await Recipient.findOne({ email });
        let donor = await Donor.findOne({ email });
        let admin = await Admin.findOne({ email: email.trim() });

         if(recipient)
         {
            
                console.log(recipient.password)
                if (recipient.password == password) {
                    let id = recipient._id;
                    let role = recipient.role
                    let name=recipient.name
                    let profilePicture=recipient.profilePicture;
                   
                    if (recipient.isBlocked) {
                        return res.status(401).json({ "Message": "Your account is blocked." });
                    }
                    let token = await jwt.sign({ id, name, role, profilePicture},
                        process.env.SECRET_KEY,
                        { expiresIn: '24h' })
                    res.json({ recipient, "Success": true, token })
                } else {
                    res.json({ "Success": false, "Message": "Invalid password" })
    
                }
            
         }
         else if(admin)
         {
                console.log(admin.password)
                if (admin.password == password) {
                    let id = admin._id;
                    let role = admin.role;
                    let name=admin.name;
                    let profilePicture=admin.profilePicture;
                   
                    let token = await jwt.sign({ id, name, role, profilePicture},
                        process.env.SECRET_KEY,
                        { expiresIn: '24h' })
                    res.json({ admin, "Success": true, token })
                } else {
                    res.json({ "Success": false, "Message": "Invalid password" })
    
                }
            
         }
        else if(donor)
        {

            console.log(donor.password)
            if (donor.password == password) {
                let id = donor._id;
                let role = donor.role;
                let name=donor.name;
                let profilePicture=donor.profilePicture;
                   
                if (donor.isBlocked) {
                    return res.status(401).json({ "Message": "Your account is blocked." });
                }
                let token = await jwt.sign({ id, name, role, profilePicture},
                    process.env.SECRET_KEY,
                    { expiresIn: '24h' })
                res.json({ donor, "Success": true, token })
            } else {
                res.json({ "Success": false, "Message": "Invalid password" })

            }
        }
        else {
            res.json({ "Success": false, "Message": "User not Found" })

        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ "Success": false, "Message": "Error during login", err: err.message });
    }

}


let addDonor = async (req, res) => {
    try {
        let data = req.body;

        // Check if profilePicture is present in the request
        let profilePicturePath = ""; // Initialize to an empty string

        if (req.files && req.files.profilePicture) {
            let profilePicture = req.files.profilePicture;
            profilePicturePath = Date.now().toString() + profilePicture.name;

            // Move the profilePicture to the uploads directory
            profilePicture.mv("./uploads/" + profilePicturePath, (err) => {
                if (err) {
                    return res.status(500).json({ "Message": "Error uploading profile picture.", err });
                }

                // Continue with Donor creation
                createDonor();
            });
        } else {
            // No profile picture provided, directly create the Donor
            createDonor();
        }

        function createDonor() {
            // Create a new Donor in the database
            Donor.create({
                name: data.name,
                email: data.email,
                password: data.password,
                phone: data.phone,
                address: data.address,
                occupation: data.occupation,
                religion: data.religion,
                profilePicture: profilePicturePath,
                isBlocked: false,
                donationHistory: []
            })
            .then(newDonor => {
                if (req.role === "admin") {
                    res.status(201).json(newDonor);
                } else {
                    res.status(403).json({ "Message": "You are not authorized for this action" });
                }
            })
            .catch(err => {
                res.status(500).json({ "Message": "Error creating a new donor.", err });
            });
        }
    } catch (err) {
        res.status(500).json({ "Message": "There was some error", err });
    }
};
const addRecipient = async (req, res) => {
    try {
        const data = req.body;
        const { profilePicture, document } = req.files;

        // Generate unique filenames to avoid overwriting
        const profilePicturePath = `${Date.now()}_${profilePicture.name}`;
        const documentPath = `${Date.now()}_${document.name}`;

        // Define the upload directory
        const uploadDirectory = './uploads/';

        // Ensure the upload directory exists
        if (!fs.existsSync(uploadDirectory)) {
            fs.mkdirSync(uploadDirectory);
        }

        // Move the files to the upload directory
        profilePicture.mv(path.join(uploadDirectory, profilePicturePath));
        document.mv(path.join(uploadDirectory, documentPath));

        // Create a new recipient with the file paths
        const newRecipient = await Recipient.create({
            name: data.name,
            email: data.email,
            password: data.password,
            cnic: data.cnic,
            occupation: data.occupation,
            income: data.income,
            needs: data.needs,
            phone: data.phone,
            address: data.address,
            religion: data.religion,
            profilePicture: profilePicturePath,
            document: documentPath
        });

        if (req.role === 'admin') {
            res.status(201).json(newRecipient);
        } else {
            res.status(403).json({ message: 'You are not authorized for this action' });
        }
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ message: 'There was some error', error });
    }
};

module.exports= {blockUser, getAllRecipients, getAllDonors, createAdmin, Login, getDonorById, getRecipientById, getAdmin, unBlockUser, updateRecipientStatus, addDonor, addRecipient};

