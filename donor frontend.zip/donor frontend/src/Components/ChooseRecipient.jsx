//ChooseRecipient.jsx
import React, { useState } from 'react';
import RecipientList from './RecipientList';
import RecipientDetails from './RecipientDetails';

const ChooseRecipient = () => {

  return (
    <div className="all_screen_padding all-screens-bg">      
      <div className="lists-container mt-5">
        <div className="list lists-containers">
          <RecipientList />
        </div>
      </div>
    </div>
  );
};

export default ChooseRecipient;

// import React, { useState, useEffect } from 'react';
// import { Link, useNavigate } from 'react-router-dom';
// import { jwtDecode } from 'jwt-decode';
// import "../App.css";
// import RecipientList from './RecipientList';

// const ChooseRecipient = () => {
//     const navigate = useNavigate();

//     const handleRecipientDonateClick = (recipientID) => {
//         navigate('/recipient-details/${recipientID}');
//     };

//     return(
//        <div>
//         <h2>
//             Recipients For Donation
//         </h2>
//         < RecipientList handleRecipientClick={handleRecipientDonateClick}/>
//        </div>
//     );
// };

// export default ChooseRecipient;




