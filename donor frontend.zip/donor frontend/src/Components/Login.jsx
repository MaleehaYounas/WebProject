
import login_logo from '../Images/login_logo.png';
import { Link, useNavigate } from 'react-router-dom';
import React, { useState } from 'react';

const LoginPage = () => 
{
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();
  const handleLogin = async () => {
    try {
      const response = await fetch('http://localhost:3001/donor/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });
  
      if (!response.ok) {
        throw new Error('Login failed');
      }
  
      const data = await response.json();
      const token = data.token;
  
      // Log the token to the console
      console.log('Token:', token);

      // Store the token in local storage
      localStorage.setItem('token', token);
      
  
      navigate('/donorPortal');
    } catch (error) {
      console.error('Error during login:', error.message);
    }
  };
  
    return (
        <section className="background3">
            <div className="container-fluid">
                <img src={login_logo} className="center" style={{ height: '7%', width: '7%', paddingTop: '5%' }} alt="" />
            </div>
            <h5 className="mt-4 text-center text-white mb-2">User Login</h5>
            {/* login section */}
            <div className="left mt-0">
                <div className="contact">
                <form>
            <input
              type="text"
              placeholder="EMAIL"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <input
              type="password"
              placeholder="PASSWORD"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </form>
                </div>
            </div>
            <div className="row m-0 mt-5">
                <div className="col-lg-6 col-md-6"></div>
                <div className="col-lg-6 col-md-6">
                    <div className="row m-0">
                        <div className="col-lg-3 col-md-3 mb-5">
                            <Link to="/" style={{ textDecoration: 'none' }}>
                                <button className="btn_bg center">Back</button>
                            </Link>
                        </div>
                        <div className="col-lg-3 col-md-3 mb-5">
                           
                                <button className="btn_bg center" onClick={handleLogin}>Login</button>
                           
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default LoginPage;
