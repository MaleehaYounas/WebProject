// // RecipientDetails.jsx
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import '../App.css';
import { jwtDecode } from 'jwt-decode';

const RecipientDetails = () => {
  const { recipientId } = useParams();
  const [recipient, setRecipient] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isBlocked, setIsBlocked] = useState(false);
  const [isNeedFulfilled, setIsNeedFulfilled] = useState(false);
  const token = localStorage.getItem('token');
  const decodedToken = jwtDecode(token);
  const name = decodedToken.name;
  const pic = decodedToken.profilePicture;

  useEffect(() => {
    const fetchRecipientDetails = async () => {
      try {
        const response = await fetch(`http://localhost:3001/admin/get-recipient-by-id/${recipientId}`, {
          headers: {
            token: token,
          },
        });

        if (!response.ok) {
          throw new Error(`Failed to fetch recipient details. Status: ${response.status}`);
        }

        const data = await response.json();
        setRecipient(data);
        setIsBlocked(data.isBlocked);
        setIsNeedFulfilled(data.isNeedFulfilled);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching recipient details:', error.message);
        setLoading(false);
      }
    };

    fetchRecipientDetails();
  }, [recipientId]);

  const handleBlockToggle = async () => {
    try {
      const token = localStorage.getItem('token');
      const action = isBlocked ? 'unblock' : 'block';

      const response = await fetch(`http://localhost:3001/admin/${action}-user/${recipientId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          token: token,
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to ${action} recipient. Status: ${response.status}`);
      }

      setIsBlocked(!isBlocked);
    } catch (error) {
      console.error(`Error ${isBlocked ? 'unblocking' : 'blocking'} recipient:`, error.message);
    }
  };

  const handleNeedToggle = async () => {
    try {
      const token = localStorage.getItem('token');

      const response = await fetch(`http://localhost:3001/admin/update-recipient-status/${recipientId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          token: token,
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to update recipient status. Status: ${response.status}`);
      }

      setIsNeedFulfilled(!isNeedFulfilled);
    } catch (error) {
      console.error(`Error updating recipient status:`, error.message);
    }
  };

   return (
    <div className="donor-portal all-screens-bg">
      <div className="container-center">
      <div className="feedback-form" >
        <h2 style={{color: 'rgb(15, 77, 99)'}}>Recipient Details </h2>
         <br></br>
        {loading ? (
         <p>Loading...</p>
       ) : recipient ? (
         <div className='text-center p-1 '>
           <p>
             Name: {recipient.name}
             {/* Profile Picture: {recipient.profilePicture}  */}
           </p> 
           <p>Email: {recipient.email}</p>
           <p>Status: {isBlocked ? 'Blocked' : 'Active'}</p>
           <p>Need Fulfilled: {isNeedFulfilled ? 'Yes' : 'No'}</p>
          <br></br> 
        <Link to="/recipientList">
           <button type="button" className="btn_bg text me-4">
                  Back
               </button>
           </Link>
          <Link to="/donation">
           <button type="button" className="btn_bg text me-4">
                   Donate
               </button>
             </Link>
      </div>
        ) : (
                 <p>Recipient not found</p>
               )}
    </div>
    </div>
    </div>
  );
};

export default RecipientDetails;
