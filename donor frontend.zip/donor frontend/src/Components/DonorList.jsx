import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { jwtDecode } from 'jwt-decode';
import "../App.css";

const DonorList = () => {
  const [donors, setDonors] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchDonors = async () => {
      try {
        const token = localStorage.getItem('token');
        console.log(token);
        const decodedToken = jwtDecode(token);

        console.log(decodedToken);

        const response = await fetch('http://localhost:3001/admin/get-all-donors', {
          headers: {
            token: token,
          },
        });

        if (!response.ok) {
          throw new Error(`Failed to fetch donors. Status: ${response.status}`);
        }

        const data = await response.json();
        setDonors(data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching donors:', error.message);
        setLoading(false);
      }
    };

    fetchDonors();
  }, []);

  const handleDonorClick = (donorId) => {
    // Navigate to DonorDetails component with the donorId
    navigate(`/donor-details/${donorId}`);
  };

  return (
    <div>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {donors.map((donor, index) => (
            <React.Fragment key={donor.id}>
              <li
                onClick={() => handleDonorClick(donor._id)}
                className="donor-recipient-list-text"
              >
                <strong>{donor.name}</strong> - {donor.email}- {donor.occupation}
              </li>
            </React.Fragment>
          ))}
        </ul>
      )}
    </div>
  );
};

export default DonorList;
