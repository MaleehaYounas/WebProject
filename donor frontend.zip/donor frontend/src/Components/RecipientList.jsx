// RecipientList.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';

import "../App.css";

const RecipientList = () => {
  const [recipients, setRecipients] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchRecipients = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await fetch('http://localhost:3001/donor/getAllRecipients', {
          headers: {
            token: token,
          },
        });

        if (!response.ok) {
          throw new Error(`Failed to fetch recipients. Status: ${response.status}`);
        }

        const data = await response.json();
        setRecipients(data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching recipients:', error.message);
        setLoading(false);
      }
    };

    fetchRecipients();
  }, []);

  const handleRecipientClick = (recipientId) => {
    navigate(`/recipient-details/${recipientId}`);
  };

  return (
    <div style={{ margin: 0 }}>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <div>
        <h2 className='text-center p-1 heading-container'>Recipients</h2>
        <ul className='text-center' style={{ listStyle: 'none', padding: 0}}>
          {recipients.map((recipient, index) => (
            <React.Fragment key={recipient.id}>
              <li
                onClick={() => handleRecipientClick(recipient._id)}
                className="donor-recipient-list-text"
              >
                <strong>{recipient.name}</strong> - {recipient.needs}
                <div>
                            <Link to="/recipient-details" style={{ textDecoration: 'none' }}>
                                <button type="button" className="btn_bg text">
                                    Donate
                                </button>
                            </Link>
                        </div>
              </li>
            </React.Fragment>
          ))}
        </ul>

        </div>
        
      )}
      <div style={{display:'flex', flexDirection:'column', justifyContent:'center', alignItems:'center'}}>
      <Link to="/donorPortal">
           <button type="button" className="btn_bg text me-4" style={{padding:'5% 25%'}} >
                  Back
               </button>
      </Link>
      </div>
    </div>
    
  );
};

export default RecipientList;
