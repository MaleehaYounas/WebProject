import React, { useState, useEffect } from 'react';
import { jwtDecode } from 'jwt-decode';

const Feedbacks = () => {
  const [feedbacks, setFeedbacks] = useState([]);
  const token = localStorage.getItem('token');

  const decodedToken = jwtDecode(token);
  const name = decodedToken.name;
  const pic = decodedToken.profilePicture;

  useEffect(() => {
    const getFeedbacks = async () => {
      try {
        const response = await fetch('http://localhost:3001/donor/feedback', {
          
        });
  
        if (!response.ok) {
          throw new Error(`Error while getting the feedbacks. Status: ${response.status}`);
        }
  
        const details = await response.json();
  
        // Fetch donor names for each feedback
        const updatedFeedbacks = await Promise.all(
          details.map(async (feedback) => {
            try {
              const Response = await fetch(`http://localhost:3001/donor/getDonorbyId/${feedback.userId}`, {
              });
  
              if (Response.ok) {
                const donorData = await Response.json();
                return { ...feedback, donorName: donorData.name };
              } else {
                console.error(`Failed to fetch donor name for userId ${feedback.userId}. Status: ${Response.status}`);
                return feedback;
              }
            } catch (error) {
              console.error('Error fetching donor name:', error.message);
              return feedback;
            }
          })
        );
  
        setFeedbacks(updatedFeedbacks);
      } catch (error) {
        console.error('Error fetching feedbacks:', error.message);
      }
    };
  
    getFeedbacks();
  }, [token]); // Include token in the dependency array
  

  return (
    <>
      <div style={{ background: '#4B7F9C', padding: '20px', borderRadius: '8px', color: '#D0D7DB' }}>
        <h2 className='text-center p-1 heading-container mb-2'>Donors Feedback</h2>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {feedbacks.map((feedback) => (
            <li
              key={feedback._id}
              style={{
                display: 'flex',
                flexDirection: 'column', // Display in a column layout
                alignItems: 'flex-start', // Align items to the start of the column
                borderBottom: '1px solid #D0D7DB',
                marginBottom: '10px',
                paddingBottom: '10px',
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
                <div>
                  <h6>{feedback.donorName}</h6>
                </div>


                <p>{new Date(feedback.createdAt).toLocaleString()}</p>
              </div>

              <p>{feedback.message}</p>
              {feedback.reply !== null && feedback.reply !== undefined && (
                <p>
                  <strong>Reply:</strong> {feedback.reply}
                </p>
              )}
            </li>
          ))}
        </ul>
      </div>
    </>
  );
};

export default Feedbacks;
