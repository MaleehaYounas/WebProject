// import React, { useState, useEffect } from 'react';
// import { Link, useNavigate } from 'react-router-dom';
// import { jwtDecode } from 'jwt-decode';
// import "../App.css";
// import RecipientList from './RecipientList';

// const ChooseRecipient = () => {
//     const navigate = useNavigate();

//     const handleRecipientDonateClick = (recipientID) => {
//         navigate('/recipient-details/${recipientID}');
//     };

//     return(
//        <div>
//         <h2>
//             Recipients For Donation
//         </h2>
//         < RecipientList handleRecipientClick={handleRecipientDonateClick}/>
//        </div>
//     );
// };

// export default ChooseRecipient;


// ChooseRecipient.jsx
import React, { useState } from 'react';
import RecipientList from './RecipientList';
import RecipientDetails from './RecipientDetails';

const ChooseRecipient = () => {
//   const [selectedRecipientId, setSelectedRecipientId] = useState(null);

//   const handleDonateClick = (recipientId) => {
//     setSelectedRecipientId(recipientId);
//   };

  return (
    <div>
      <h2>Choose Recipient</h2>
      {/* <div style={{ display: 'flex' }}>
        <div style={{ flex: 1 }}>
         
          <RecipientList onDonateClick={handleDonateClick} />
        </div>
        <div style={{ flex: 2 }}>
          
          {selectedRecipientId ? (
            <RecipientDetails recipientId={selectedRecipientId} />
          ) : (
            <p>Please select a recipient to donate.</p>
          )}
        </div>
      </div> */}
        <div className="lists-container mt-5">
        {/* <div className="list lists-containers">
          <h3 style={{ color: '#fff' }}>Donors</h3>
          <DonorList />
        </div> */}

        <div className="list lists-containers">
          <h3 style={{ color: '#fff' }}>Recipients</h3>
          <RecipientList />
        </div>
      </div>
    </div>
  );
};

export default ChooseRecipient;

