const {createDonor, getAllDonors, getDonorById, updateDonorById, deleteDonorById, giveAppFeedback, getAllFeedback, getAllRecipients} = require("../Controller/DonorController")
const searchDonor = require("../Controller/SearchController");
const express = require("express");
const { AuthenticateUser, Login} = require("../utils");
const router2 = express.Router();

router2.post("/login", Login);
router2.get("/" ,getAllDonors)
router2.get("/getDonorbyId/:id" ,getDonorById)
router2.post("/create" , createDonor)
router2.patch("/:id" , updateDonorById)
router2.delete("/:id" ,  deleteDonorById)
router2.post('/feedback', giveAppFeedback);
router2.get('/feedback', getAllFeedback); 
router2.get("/getAllRecipients" , getAllRecipients)
// router2.post("/searchDonor" ,AuthenticateUser, searchByName )
router2.post("/searchDonor" , searchDonor )



module.exports = router2;
