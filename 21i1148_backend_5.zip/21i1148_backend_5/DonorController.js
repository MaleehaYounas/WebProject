const Donor = require("../models/Donor.schema");
const Recipient = require("../models/Recipient.schema");
const jwt = require("jsonwebtoken");
const Feedback = require("../models/Feedback.schema");


let getAllDonors = async (req, res) => {
    try {
        // Assuming req.query.role is used to filter by role
        
        const roleFilter = req.query.role;

        // Constructing the query based on the role filter
        const query = roleFilter ? { role: roleFilter } : {};

        let donors = await Donor.find({});
        res.status(200).json(donors);
    } catch (err) {
        res.status(500).json({ "Message": "Error", err: err });

    }
};

let getDonorById = async (req, res) => {
    let id = req.params.id;
    try {
        let donor = await Donor.findOne({ _id: id });
        if (donor) {
            res.status(200).json(donor);
        } else {
            res.status  (404).json({ "Message": "Donor not found" });
        }
    } catch (err) {
        res.status(500).json({ "Message": "Error", err: err });
    }
};

let createDonor = async (req, res) => {
    let data = req.body;
    let { profilePicture } = req.files;

    let profilePicturePath = Date.now().toString() + profilePicture.name;

    try {
        profilePicture.mv("./uploads/" + profilePicturePath);

        let newDonor = await Donor.create({
            name: data.name,
            email: data.email,
            password: data.password,
            phone: data.phone,
            address: data.address,
            occupation: data.occupation,
            religion: data.religion,
            profilePicture: profilePicturePath,
            isBlocked: false,
            donationHistory: []
        });

        res.status(201).json(newDonor);
    } catch (err) {
        res.status(500).json({ "Message": "There was some error", err });
    }
};

let updateDonorById = async (req, res) => {
    let id = req.params.id;
    let data = req.body;

    try {
        let donor = await Donor.findByIdAndUpdate(id, data);
        if (donor) {
            res.status(200).json(donor);
        } else {
            res.status(404).json({ "Message": "Donor not found" });
        }
    } catch (err) {
        res.status(500).json({ "Message": "Error", err: err });
    }
};

let deleteDonorById = async (req, res) => {
    let id = req.params.id;
    try {
        let donor = await Donor.findByIdAndDelete(id);
        if (donor) {
            res.status(200).json(donor);
        } else {
            res.status(404).json({ "Message": "Donor not found" });
        }
    } catch (err) {
        res.status(500).json({ "Message": "Error", err: err });
    }
};

const giveAppFeedback = async (req, res) => {
    try{
        console.log('Request Body:', req.body);     //to check what is being stored in the database
        const {userName, userId, userRole, message} = req.body;

        const feedback = new Feedback({
            userName,
            userId,
            userRole,
            message,
        });

        const newFeedback = await feedback.save(); //inorder to save the given feedback

        res.status(201).json(newFeedback);
    }catch(error)
    {
        console.error(error);
        console.error("Error while giving feedback:", error);
        res.status(500).json({ error: 'Error while giving feedback' });
    }
};

  // Controller to retrieve all feedback
  const getAllFeedback = async (req, res) => {
    try {
      // Retrieve all feedback from the database
      const allFeedback = await Feedback.find({});
  
      res.status(200).json(allFeedback);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  };
  
  let getAllRecipients = async (req, res) => {
    try {
        let recipients = await Recipient.find({});
        res.status(200).json(recipients);
    } catch (err) {
        res.status(500).json({ "Message": "Error", err: err });
    }
};

// const searchDonor = async (req, res) => {
//     try {
//       const searchname = req.body.name;
      
//       console.log(searchname);
  
//       // Check if the nameToSearch is empty
//       if (!searchname) {
//         // If empty, return all donors
//         const allRecipients = await Recipient.find().sort({ createdAt: -1 });
  
//         // Respond with all donors
//         return res.status(200).json({ donors: allRecipients });
//       }
  
//       // Writing query to search for the name in both donors and recipients
//       const recipientQuery = { name: { $regex: searchname, $options: 'i' } };
  
//       // Execute the query for donors
//       const Results = await Donor.find(recipientQuery).sort({ createdAt: -1 });
  
//       // Combine the results for donors
//       const searchResults = {
//         donors: Results,
//       };
  
//       // Respond with the search results
//       res.status(200).json(searchResults);
//     } catch (err) {
//       console.error(err);
//       res.status(500).json({ message: 'Server error' });
//     }
//   };

module.exports = {
    getAllDonors,
    getDonorById,
    createDonor,
    updateDonorById,
    deleteDonorById,
    giveAppFeedback,
    getAllFeedback,
    getAllRecipients,
};