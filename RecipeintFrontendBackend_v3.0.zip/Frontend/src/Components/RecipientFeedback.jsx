import React, { useState, useEffect } from 'react';

const FeedbackList = () => {
  const [feedback, setFeedback] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchFeedback = async () => {
      try {
        // Fetch feedback from the server
        const response = await fetch('http://localhost:3003/recipient/Feedback');

        if (!response.ok) {
          throw new Error(`Failed to fetch feedback. Status: ${response.status}`);
        }

        const data = await response.json();
        setFeedback(data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching feedback:', error.message);
        setLoading(false);
      }
    };

    fetchFeedback();
  }, []);

  return (
    <div className="container mt-5">
      <h1 className="mb-4">Recipient's Feedback </h1>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <div>
          {feedback.map((item) => (
            <div key={item._id} className="card mb-3">
              <div className="card-body">
                <h5 className="card-title"> {item.userName}</h5>
                <p className="card-text">{item.message}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default FeedbackList;
