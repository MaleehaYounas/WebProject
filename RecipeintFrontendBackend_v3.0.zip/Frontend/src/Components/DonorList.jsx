import React, { useState, useEffect } from "react";
import { Modal, Button } from "react-bootstrap";
import RateReviewIcon from "@mui/icons-material/RateReview";

const DonorList = () => {
  const [donors, setDonors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [feedbackText, setFeedbackText] = useState("");
  const [feedbackSuccess, setFeedbackSuccess] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [requestStatus, setRequestStatus]= useState("");
  const [recipient, setRecipient]= useState("");

  const handleInputChange = (e) => {
    setSearchTerm(e.target.value);
  };

  useEffect(() => {
    const fetchDonors = async () => {
      try {
        const token = localStorage.getItem("token");
        const response = await fetch(
          `http://localhost:3003/recipient/searchDonor`,
          {
            method: "POST",
            headers: {
              token: token,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              name: searchTerm,
            }),
          }
        );

        if (!response.ok) {
          throw new Error(`Failed to fetch donors. Status: ${response.status}`);
        }

        const data = await response.json();
        setDonors(data.donors);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching donors:", error.message);
        setLoading(false);
      }
    };

    fetchDonors();
  },  );


  useEffect(() => {
const getRecipientName = async () => {
  try{
    const token = localStorage.getItem("token");

    const response3 = await fetch(
      `http://localhost:3003/recipient/recipientName`,
      {
        headers: {
          "Content-Type": "application/json",
          token: token,
        },
      }
    );

    if (!response3.ok) {
      throw new Error(`Failed to send request. Status: ${response3.status}`);
    }

    const data3=  await response3.json();
    setRecipient(data3);
 
  }
  catch(error) {
    console.error("Error fetching recipient Name:", error.message);
  }
}
getRecipientName();
 }, );



  const handleFeedbackButton = () => {
    setShowModal(true);
    setFeedbackSuccess(false);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setFeedbackText("");
    setFeedbackSuccess(false);
  };

  const handleSendRequest = async (donorId) => {
    try {
      const token = localStorage.getItem("token");

      const response = await fetch(
        `http://localhost:3003/recipient/sendRequest/${donorId}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            token: token,
          },
        }
      );

      if (!response.ok) {
        throw new Error(`Failed to send request. Status: ${response.status}`);
      }

      const data=  await response.json();
      console.log(data);
   
      const response2 = await fetch(
        `http://localhost:3003/recipient/getRequestStatus/${donorId}`,
        {
          headers: {
            "Content-Type": "application/json",
            token: token,
          },
        }
      );

      if (!response2.ok) {
        throw new Error(`Failed to send request. Status: ${response2.status}`);
      }

      const data2=  await response2.json();
      setRequestStatus(data2.requestStatus);
    

    } catch (error) {
      console.error("Error sending request:", error.message);
    }
  };

  const handleSendFeedback = async () => {
    try {
      const token = localStorage.getItem("token");
      console.log("Token:", token);

      const response = await fetch("http://localhost:3003/recipient/feedback", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          token: token,
        },

        body: JSON.stringify({
          message: feedbackText,
        }),
      });

      if (!response.ok) {
        throw new Error(`Failed to send feedback. Status: ${response.status}`);
      }

      console.log("Feedback sent successfully");
      setFeedbackSuccess(true);
    } catch (error) {
      console.error("Error sending feedback:", error.message);
      setFeedbackSuccess(false); // Set feedback success status
    }
  };

  return (
    <section style={{ paddingTop: "40px", backgroundColor: "#4B7F9C" }}>
      <div className="container">
        <div className="mb-3">
          <input
            type="text"
            className="form-control"
            placeholder="Search by donor name"
            name="searchTerm"
            value={searchTerm}
            onChange={handleInputChange}
          />
        </div>

        <div
          className="row justify-content-center"
          style={{ backgroundColor: "#D9D9D9 !important" }}
        >
          <div
            className="col-md-8"
            style={{ backgroundColor: "#D9D9D9 !important" }}
          >
            {loading ? (
              <p>Loading...</p>
            ) : (
              <ul
                className="list-group"
                style={{ backgroundColor: "#D9D9D9 !important" }}
              >
                {donors.map((donor) => (
                  <li
                    key={donor._id}
                    className="list-group-item d-flex justify-content-between align-items-center"
                  >
                    <div>
                      <h5 className="mb-1">
                        <strong>{donor.name}</strong>
                      </h5>
                      <p className="mb-1">{donor.email}</p>
                      <p className="mb-1">{donor.occupation}</p>
                    </div>

                    {!donor.requests.some(
                      (request) => request.recipientName === recipient
                    ) ? (
                      <button
                        type="button"
                        className="btn btn-primary"
                        style={{ backgroundColor: "#4B7F9C", border: "none" }}
                        
                        onClick={() => handleSendRequest(donor._id)}
                      >
                        Send Request 
                      </button>
                    ) : donor.requests.some(
                        (request) =>
                          request.recipientName === recipient &&
                          request.requestStatus === "pendingRequest"
                      ) ? (
                      <button
                        type="button"
                        className="btn btn-primary"
                        style={{ backgroundColor: "#4B7F9C", border: "none" }}
                        disabled
                      >
                        Pending Request
                      </button>
                    ) : donor.requests.some(
                        (request) =>
                          request.recipientName === recipient &&
                          request.requestStatus === "confirmRequest"
                      ) ? (
                      <button
                        type="button"
                        className="btn btn-primary"
                        style={{ backgroundColor: "#4B7F9C", border: "none" }}
                        // onClick={() => handleSendMessage(donor._id)}
                      >
                        Send Message
                      </button>
                    ) : (
                      <p>Send Request</p>
                    )}


                  </li>
                ))}
              </ul>
            )}
            {/* Feedback button */}
            <button
              type="button"
              className="btn btn-success feedback-button"
              style={{
                marginTop: "20px",
                marginLeft: "800px",
                width: "170px",
                backgroundColor: "#D9D9D9",
                color: "black",
              }}
              onClick={handleFeedbackButton}
            >
              <RateReviewIcon />
              Give Feedback
            </button>
          </div>
        </div>
      </div>
      {/* Modal for feedback */}
      <Modal show={showModal} onHide={handleCloseModal}>
        <Modal.Header closeButton>
          <Modal.Title>Give Feedback About Our App</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <textarea
            className="form-control"
            rows="4"
            placeholder="Enter your feedback here"
            value={feedbackText}
            onChange={(e) => setFeedbackText(e.target.value)}
          />
          {feedbackSuccess && (
            <p className="text-success">Feedback sent successfully!</p>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseModal}>
            Close
          </Button>
          <Button variant="primary" onClick={handleSendFeedback}>
            Send
          </Button>
        </Modal.Footer>
      </Modal>
      .
    </section>
  );
};

export default DonorList;
