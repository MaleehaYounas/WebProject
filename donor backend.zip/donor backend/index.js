const express = require("express")
const mongoose  =require("mongoose")
const upload = require("express-fileupload")
const cors = require('cors');
const app = express();
app.use(express.json());
app.use(cors());

//const SearchRouter = require("./Routes/SearchRoutes");
const AdminRouter = require("./Routes/AdminRoutes");
const RecipientRouter = require("./Routes/RecipientRoutes");
const DonorRouter = require("./Routes/DonorRoutes");
require("dotenv").config()

app.use(upload())
app.use("/uploads" , express.static("uploads"))

app.listen(3001)
//app.use("/search" ,  SearchRouter)
app.use("/admin" ,  AdminRouter)
app.use("/recipient" ,  RecipientRouter)
app.use("/donor" ,  DonorRouter)
mongoose.connect(process.env.MONGODB_STRING).then(()=>{
    console.log("Connected")
}).catch(err=>{
    console.log(err)
})
