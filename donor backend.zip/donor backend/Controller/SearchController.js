const Donor = require("../models/Donor.schema");
const Recipient = require("../models/Recipient.schema");
const jwt = require("jsonwebtoken");

const searchDonor = async (req, res) => {
  try {
    const searchname = req.body.name;
    
    console.log(searchname);

    // Check if the nameToSearch is empty
    if (!searchname) {
      // If empty, return all donors
      const allRecipients = await Recipient.find().sort({ createdAt: -1 });

      // Respond with all donors
      return res.status(200).json({ donors: allRecipients });
    }

    // Writing query to search for the name in both donors and recipients
    const RecipientQuery = { name: { $regex: searchname, $options: 'i' } };

    // Execute the query for donors
    const Results = await Recipient.find(RecipientQuery).sort({ createdAt: -1 });

    // Combine the results for donors
    const searchResults = {
      donors: Results,
    };

    // Respond with the search results
    res.status(200).json(searchResults);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};
module.exports = searchDonor;
