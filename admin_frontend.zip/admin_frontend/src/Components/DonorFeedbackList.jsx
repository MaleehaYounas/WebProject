import React, { useState, useEffect } from 'react';
import { jwtDecode } from 'jwt-decode';

const DonorFeedbackList = ({ onReply }) => {
  const [feedbacks, setFeedbacks] = useState([]);
  const [replyInputs, setReplyInputs] = useState({}); // State to track reply inputs for each feedback
  const token = localStorage.getItem('token');

  const decodedToken = jwtDecode(token);
  const name = decodedToken.name;
  const pic = decodedToken.profilePicture;

  useEffect(() => {
    const fetchDonorFeedbacks = async () => {
      try {
        const response = await fetch('http://localhost:3001/admin/feedback/donor', {
          
        });
  
        if (!response.ok) {
          throw new Error(`Failed to fetch donor feedbacks. Status: ${response.status}`);
        }
  
        const data = await response.json();
  
        // Fetch donor names for each feedback
        const updatedFeedbacks = await Promise.all(
          data.map(async (feedback) => {
            try {
              const donorResponse = await fetch(`http://localhost:3001/admin/get-donor-by-id/${feedback.userId}`, {
              });
  
              if (donorResponse.ok) {
                const donorData = await donorResponse.json();
                return { ...feedback, donorName: donorData.name };
              } else {
                console.error(`Failed to fetch donor name for userId ${feedback.userId}. Status: ${donorResponse.status}`);
                return feedback;
              }
            } catch (error) {
              console.error('Error fetching donor name:', error.message);
              return feedback;
            }
          })
        );
  
        setFeedbacks(updatedFeedbacks);
  
        // Initialize replyInputs with an empty object for each feedback
        const initialReplyInputs = updatedFeedbacks.reduce((acc, feedback) => {
          acc[feedback._id] = '';
          return acc;
        }, {});
        setReplyInputs(initialReplyInputs);
      } catch (error) {
        console.error('Error fetching feedbacks:', error.message);
      }
    };
  
    fetchDonorFeedbacks();
  }, [token]); // Include token in the dependency array
  
  const handleReply = async (feedbackId) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`http://localhost:3001/admin/feedback/${feedbackId}/reply`, {
        method: 'put',
        headers: {
          'Content-Type': 'application/json',
          token: token,
        },
        body: JSON.stringify({ reply: replyInputs[feedbackId] }), // Use the corresponding reply input
      });

      if (!response.ok) {
        throw new Error(`Failed to reply. Status: ${response.status}`);
      }

      // Update the feedbacks with the new reply
      setFeedbacks((prevFeedbacks) =>
        prevFeedbacks.map((feedback) =>
          feedback._id === feedbackId ? { ...feedback, reply: replyInputs[feedbackId] } : feedback
        )
      );
    } catch (error) {
      console.error('Error replying on feedback:', error.message);
    }
  };

  return (
    <>
      <div style={{ background: '#4B7F9C', padding: '20px', borderRadius: '8px', color: '#D0D7DB' }}>
        <h2 className='text-center p-1 heading-container mb-2'>Donors Feedback</h2>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {feedbacks.map((feedback) => (
            <li
              key={feedback._id}
              style={{
                display: 'flex',
                flexDirection: 'column', // Display in a column layout
                alignItems: 'flex-start', // Align items to the start of the column
                borderBottom: '1px solid #D0D7DB',
                marginBottom: '10px',
                paddingBottom: '10px',
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
                <div>
                  <h6>{feedback.donorName}</h6>
                </div>


                <p>{new Date(feedback.createdAt).toLocaleString()}</p>
              </div>

              <p>{feedback.message}</p>
              {feedback.reply !== null && feedback.reply !== undefined && (
                <p>
                  <strong>Reply:</strong> {feedback.reply}
                </p>
              )}
              <div style={{ display: 'flex', width: '100%' }}>
                <textarea
                  rows={1} // Display as a multiline text area
                  placeholder="Type your reply..."
                  value={replyInputs[feedback._id]}
                  onChange={(e) => setReplyInputs((prev) => ({ ...prev, [feedback._id]: e.target.value }))}
                  style={{ marginRight: '10px', width: '90%', borderRadius: '40px' }} // Adjust the width as needed
                />
                <button
                  onClick={() => handleReply(feedback._id)}
                  style={{
                    padding: '5px 10px',
                    background: '#D0D7DB',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: 'pointer',
                  }}
                >
                  Reply
                </button>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </>
  );
};

export default DonorFeedbackList;
