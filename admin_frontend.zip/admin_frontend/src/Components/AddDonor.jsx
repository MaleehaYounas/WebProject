import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

const DonorRegistration = () => {
    const token=localStorage.getItem('token');
    const [formData, setFormData] = useState({
        name: '',
        role: 'donor',
        email: '',
        password: '',
        cnic: '',
        occupation: '',
        profilePic: null,
        phoneNum: '',
        address: '',
        religion: '',
    });

    const navigate = useNavigate();

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleFileChange = (e) => {
        const { name, files } = e.target;
        setFormData({ ...formData, [name]: files[0] });
    };

    const handleRegister = async () => {
    try {
        const response = await fetch('http://localhost:3001/admin/add-donor', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                token: token,
            },
            body: JSON.stringify(formData),
        });

        if (!response.ok) {
            console.error('Error response:', await response.text());
            throw new Error(`Failed to add donor. Status: ${response.status}`);
        }

        const contentType = response.headers.get('content-type');
        if (contentType && contentType.includes('application/json')) {
            const result = await response.json();
            console.log('Donor created:', result);
        } else {
            console.error('Invalid response format. Expected JSON.');
        }
    } catch (error) {
        console.error('Error:', error);
    }
};

    return (
        <div>
            <section className="background3">
                <form onSubmit={handleRegister} className="rounded p-4">
                    <div className="row m-0 text-white text">
                        <div className="col-md-6">
                            <h2 className="text-left mb-4 text-primary text-white">Add Donor</h2>
                            <div className="mb-3">
                                <label className="form-label">Name:</label>
                                <input type="name" name="name" className="form-control" onChange={handleInputChange} style={{ width: '100%' }} />
                            </div>

                            <div className="mb-3">
                                <label className="form-label">Email:</label>
                                <input type="email" name="email" className="form-control" onChange={handleInputChange} style={{ width: '100%' }} />
                            </div>

                            <div className="mb-3">
                                <label className="form-label">Password:</label>
                                <input type="password" name="password" className="form-control" onChange={handleInputChange} style={{ width: '100%' }} />
                            </div>

                            <div className="mb-3">
                                <label className="form-label">CNIC:</label>
                                <br></br>
                                <input type="text" name="cnic" className="form-control" onChange={handleInputChange} style={{ width: '100%' }} />
                            </div>

                            <div className="mb-3">
                                <label className="form-label">Occupation:</label>
                                <input type="text" name="occupation" className="form-control" onChange={handleInputChange} style={{ width: '100%' }} />
                            </div>
                        </div>

                        <div className="col-md-6">
                            <br></br>
                            <br></br>
                            <br></br>
                            <div className="mb-3">

                                <label className="form-label">Profile Picture:</label>
                                <input type="file" name="profilePicture" className="form-control" onChange={handleFileChange} style={{ width: '100%' }} />
                            </div>

                            <div className="mb-3">
                                <label className="form-label">Phone:</label>
                                <input type="tel" name="phone" className="form-control" onChange={handleInputChange} style={{ width: '100%' }} />
                            </div>

                            <div className="mb-3">
                                <label className="form-label">Address:</label>
                                <textarea name="address" className="form-control" onChange={handleInputChange} style={{ width: '100%' }}></textarea>
                            </div>

                            <div className="mb-3">
                                <label className="form-label">Religion:</label>
                                <input type="text" name="religion" className="form-control" onChange={handleInputChange} style={{ width: '100%' }} />
                            </div>

                        </div>
                        <br></br>
                        <br></br>
                        <br></br>
                    </div>
                    <br></br>
                    <div className='text-center regbtncontainer'>
                        <div>
                            <Link to="/adminPortal" style={{ textDecoration: 'none' }}>
                                <button type="button" className="btn_bg text">
                                    Back
                                </button>
                            </Link>
                        </div>
                        <div className="me-5">
                            <button type="submit" className="btn_bg text me-4">
                                Add
                            </button>
                        </div>
                    </div>
                </form>
            </section>
        </div>
    );


};

export default DonorRegistration;
