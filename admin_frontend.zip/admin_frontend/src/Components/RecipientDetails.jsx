// RecipientDetails.jsx
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import '../App.css';
import { jwtDecode } from 'jwt-decode';

const RecipientDetails = () => {
  const { recipientId } = useParams();
  const [recipient, setRecipient] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isBlocked, setIsBlocked] = useState(false);
  const [isNeedFulfilled, setIsNeedFulfilled] = useState(false);
  const token = localStorage.getItem('token');
  const decodedToken = jwtDecode(token);
  const name = decodedToken.name;
  const pic = decodedToken.profilePicture;

  useEffect(() => {
    const fetchRecipientDetails = async () => {
      try {
        const response = await fetch(`http://localhost:3001/admin/get-recipient-by-id/${recipientId}`, {
          headers: {
            token: token,
          },
        });

        if (!response.ok) {
          throw new Error(`Failed to fetch recipient details. Status: ${response.status}`);
        }

        const data = await response.json();
        setRecipient(data);
        setIsBlocked(data.isBlocked);
        setIsNeedFulfilled(data.isNeedFulfilled);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching recipient details:', error.message);
        setLoading(false);
      }
    };

    fetchRecipientDetails();
  }, [recipientId]);

  const handleBlockToggle = async () => {
    try {
      const token = localStorage.getItem('token');
      const action = isBlocked ? 'unblock' : 'block';

      const response = await fetch(`http://localhost:3001/admin/${action}-user/${recipientId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          token: token,
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to ${action} recipient. Status: ${response.status}`);
      }

      setIsBlocked(!isBlocked);
    } catch (error) {
      console.error(`Error ${isBlocked ? 'unblocking' : 'blocking'} recipient:`, error.message);
    }
  };

  const handleNeedToggle = async () => {
    try {
      const token = localStorage.getItem('token');

      const response = await fetch(`http://localhost:3001/admin/update-recipient-status/${recipientId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          token: token,
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to update recipient status. Status: ${response.status}`);
      }

      setIsNeedFulfilled(!isNeedFulfilled);
    } catch (error) {
      console.error(`Error updating recipient status:`, error.message);
    }
  };

  return (
    <div className="all_screen_padding all-screens-bg">
      <div className="profile-container">
        <div className="profile-info">
          <img src={`http://localhost:3001/uploads/${pic}`} className="img-dim round-image" alt={pic} />
          <h4 style={{ marginLeft: '20px' }}>{name}</h4>
        </div>
      </div>
      <div className='user-details-container'>
        <h2>Recipient Profile</h2>
        {loading ? (
          <p>Loading...</p>
        ) : recipient ? (
          <div className='user-details-content'>
            <div className='user-details-column'>
              <p><strong>Name:</strong> {recipient.name}</p>
              <p><strong>Email:</strong> {recipient.email}</p>
              <p><strong>Phone:</strong> {recipient.phone}</p>
              <p><strong>Address:</strong> {recipient.address}</p>
              <p><strong>Occupation:</strong> {recipient.occupation}</p>
              <p><strong>Religion:</strong> {recipient.religion}</p>
              <strong>Document:</strong>


              <a
                href={`http://localhost:3001/uploads/${recipient.document}`}
                target="_blank"
                rel="noopener noreferrer"
              > {recipient.document} </a>

            </div>
            <div className='user-details-column'>
              <img src={`http://localhost:3001/uploads/${recipient.profilePicture}`} alt='Profile' className='profile-image' />
              <p><strong>Status:</strong> {isBlocked ? 'Blocked' : 'Active'}</p>
              <p><strong>Need Fulfilled:</strong> {isNeedFulfilled ? 'Yes' : 'No'}</p>
              <div>



              </div>

              <button onClick={handleBlockToggle} className="btn_dark_bg text-white">
                {isBlocked ? 'Unblock Recipient' : 'Block Recipient'}
              </button>
              <button onClick={handleNeedToggle} className='ms-3 btn_dark_bg text-white'>
                {isNeedFulfilled ? 'Mark Need Not Fulfilled' : 'Mark Need Fulfilled'}
              </button>
            </div>
          </div>
        ) : (
          <p>Recipient not found</p>
        )}
      </div>
    </div>
  );
};

export default RecipientDetails;
