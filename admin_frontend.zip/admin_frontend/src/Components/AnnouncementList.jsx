import React, { useState, useEffect } from 'react';
import { jwtDecode } from 'jwt-decode';

const AnnouncementList = ({ onDelete }) => {
  const [announcements, setAnnouncements] = useState([]);
  const token = localStorage.getItem('token');
      
  const decodedToken = jwtDecode(token);
  const name = decodedToken.name;
  const pic = decodedToken.profilePicture;
  useEffect(() => {
    const fetchAnnouncements = async () => {
      try {
       
        const response = await fetch('http://localhost:3001/admin/announcement/get-all-announcements', {
          headers: {
            token: token,
          },
        });

        if (!response.ok) {
          throw new Error(`Failed to fetch announcements. Status: ${response.status}`);
        }

        const data = await response.json();
        setAnnouncements(data);
      } catch (error) {
        console.error('Error fetching announcements:', error.message);
      }
    };

    fetchAnnouncements();
  }, []);

  const handleDelete = async (announcementId) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`http://localhost:3001/admin/announcement/delete-announcement/${announcementId}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          token: token,
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to delete announcement. Status: ${response.status}`);
      }

      setAnnouncements((prevAnnouncements) => prevAnnouncements.filter((a) => a._id !== announcementId));
    } catch (error) {
      console.error('Error deleting announcement:', error.message);
    }
  };

  return (
    <>
    <div className="profile-container">
        <div className="profile-info">
          <img src={`http://localhost:3001/uploads/${pic}`} className="img-dim round-image" alt={pic} />
          <h4 style={{ marginLeft: '20px' }}>{name}</h4>
        </div>
    </div>
    <div style={{ background: '#4B7F9C', padding: '20px', borderRadius: '8px', color: '#D0D7DB' }}>
     
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {announcements.map((announcement) => (
          <li
            key={announcement._id}
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              borderBottom: '1px solid #D0D7DB',
              marginBottom: '10px',
              paddingBottom: '10px',
            }}
          >
            <div>
              <h6>{announcement.title}</h6>
              <p>{announcement.content}</p>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end' }}>
              <p>{new Date(announcement.createdAt).toLocaleString()}</p>
              <button
                onClick={() => handleDelete(announcement._id)}
                style={{
                  padding: '5px 10px',
                  background: '#D0D7DB',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                }}
              >
                Delete
              </button>
            </div>
          </li>
        ))}
      </ul>
    </div>
    </>
  );
};

export default AnnouncementList;
