import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../App.css';

const AddAnnouncement = ({ onAdd }) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
 const navigate = useNavigate();
  const handleAdd = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:3001/admin/announcement/add-announcement', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          token: token,
        },
        body: JSON.stringify({
          title: title,
          content: content,
        }),
      });

      if (!response.ok) {
        throw new Error(`Failed to add announcement. Status: ${response.status}`);
      }

      const data = await response.json();
      navigate('/announcement-list');
      onAdd(data);
      setTitle('');
      setContent('');
      
    } catch (error) {
      console.error('Error adding announcement:', error.message);
    }
  };

  return (
    <div className="add-announcement-container">
      <div className="form-group">
        <label htmlFor="title" className="label">Title:</label>
        <input
          type="text"
          id="title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="form-control"
        />
      </div>
      <div className="form-group">
        <label htmlFor="content" className="label">Content:</label>
        <textarea
          id="content"
          value={content}
          onChange={(e) => setContent(e.target.value)}
          className="form-control"
        />
      </div>
      <button onClick={handleAdd} className='btn_dark_bg text-white btn-submit'>Add Announcement</button>
    </div>
  );
};

export default AddAnnouncement;
