import React, {useState, useEffect} from "react";
import {jwtDecode} from 'jwt-decode';
import '../App.css';

const DonorDetails = ({match}) => {
    const token = localStorage.getItem('token');
    const decodedToken = jwtDecode(token);    //token after being decoded
    const id_donor = decodedToken.id;

    if (token) {
        try {
          const decodedToken = jwtDecode(token);
          console.log('Decoded Token:', decodedToken);
        } catch (error) {
          console.error('Error decoding token:', error);
        }
      } else {
        console.error('Token not found.');
      }
    const [donor, setDonor] = useState(null);
    const [updateDonor, setUpdateDonor] = useState(null);
    const [isUpdating, setUpdating] = useState(null);

    useEffect (() => {
        const fetchDonorbyId = async () => {
            try{
              const res = await fetch(`http://localhost:3000/donor/${id_donor}`, {
                method:'GET',
                headers: {
                    'Data' : 'application/json',
                    token: token,
                }
              });
              if(res.ok)
              {
                const donorDetails = await res.json();
                setDonor(donorDetails);
                setUpdateDonor(donorDetails);
              }
              else{
                console.error('Error while fetching the donor:', res.status);
              }
            }catch(error)
            {
                console.error('Error fetching the donor:', error);
            }
        };

        fetchDonorbyId();
    }, [id_donor, token]);

    const handleUpdateDonorClick = () => {
        setUpdating(true);
    };

    const handleSaveDetailsClick = async () =>{
        try{
            const res = await fetch(`http://localhost:3000/donor/${id_donor}`, {
                method: 'POST',
                headers: {
                    'Data' : 'application/json',
                    token: token,
                },
                body: JSON.stringify(updateDonor),
            });
            if(res.ok)
            {
                const donorUpdate = await res.json();
                setUpdateDonor(donorUpdate);
                setDonor(donorUpdate);
                setUpdating(false);  //update disabled. Now donor cannot be updated by himself.
            }
            else{
                console.error('Error in editing the Donor:', res.status);
            }
        }catch(error)
        {
            console.error('Error in updating the Donor:', error);
        }
    };

    const handleInput = (e) => {
        const {donName, val} = e.target;
        setUpdateDonor((prevDonorUpdate) => ({
             ...prevDonorUpdate, [donName]: val,
        }));
    };

    return (
        <div className="container mt-5">
      { donor ? (
        <div>

          <h2>{donor.name}</h2>
          <p>Email: {donor.email}</p>

          {isUpdating ? (
            <>
              <label>Occupation:</label>
              <input
                type="text"
                name="occupation"
                value={updateDonor.occupation}
                onChange={handleInput}
              />
              <br />

              <label>Phone:</label>
              <input
                type="tel"
                name="phone"
                value={updateDonor.phone}
                onChange={handleInput}
              />
              <br />

              <label>Address:</label>
              <textarea
                name="address"
                value={updateDonor.address}
                onChange={handleInput}
              ></textarea>
              <br />

              <label>Religion:</label>
              <input
                type="text"
                name="religion"
                value={updateDonor.religion}
              />
              <br />

              <button onClick={handleSaveDetailsClick}>Save</button>
            </>
          ) : (
            <>
              <p>Occupation: {donor.occupation}</p>
              <p>Phone: {donor.phone}</p>
              <p>Address: {donor.address}</p>
              <p>Religion: {donor.religion}</p>
              <button onClick={handleUpdateDonorClick}>Edit</button>
            </>
          )}
        </div>
      ) : (
        <p>Loading...</p>
      )}
    </div>
    );
};

export default DonorDetails;
